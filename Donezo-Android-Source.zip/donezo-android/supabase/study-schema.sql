create table public.donezo_study (
  user_id uuid primary key default auth.uid() references auth.users(id) on delete cascade,
  revision integer not null check (revision >= 1),
  data jsonb not null check (
    jsonb_typeof(data) = 'object'
    and data ?& array['subjects', 'tasks', 'goals', 'logs']
    and jsonb_typeof(data -> 'subjects') = 'array'
    and jsonb_typeof(data -> 'tasks') = 'array'
    and jsonb_typeof(data -> 'goals') = 'array'
    and jsonb_typeof(data -> 'logs') = 'array'
    and octet_length(data::text) <= 1048576
  )
);
alter table public.donezo_study enable row level security;
revoke all on table public.donezo_study from public, anon, authenticated;
grant select, insert, update on table public.donezo_study to authenticated;
create policy "Read own learning records" on public.donezo_study
  for select to authenticated using ((select auth.uid()) = user_id);
create policy "Create own learning records" on public.donezo_study
  for insert to authenticated with check ((select auth.uid()) = user_id);
create policy "Update own learning records" on public.donezo_study
  for update to authenticated using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);
