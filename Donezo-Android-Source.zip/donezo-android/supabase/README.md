# Donezo 的 Supabase 配置

应用已内置 Donezo 项目地址和可公开的客户端密钥。数据库密码只在管理数据库时使用。

## 开通邮箱验证码

1. 打开 [Donezo 邮件模板](https://supabase.com/dashboard/project/kifuczvkkfayaqfneqno/auth/templates)。
2. 在 **Magic Link** 和 **Confirm signup** 两个模板中，都填入验证码正文并保存：

   ```html
   <p>你的 Donezo 验证码是 <strong>{{ .Token }}</strong>。</p>
   <p>请在应用内输入验证码。</p>
   ```

3. 用项目团队成员的邮箱测试默认发信。打开 App 的「个人中心 → 邮箱注册 / 登录」，输入邮箱，发送验证码并登录。
4. 开放其他邮箱注册时，在 Supabase 后台配置自定义 SMTP。使用 QQ 邮箱发信时，把发件地址和 SMTP 授权码填在 Supabase 的 SMTP 设置里，先测试投递。授权码留在后台。

[验证码说明](https://supabase.com/docs/guides/auth/auth-email-passwordless) · [自定义发信说明](https://supabase.com/docs/guides/auth/auth-smtp)

## 学习记录

首次在新设备登录会读取云端记录。旧设备的数据可从「导入本机记录」导入，再点「保存到云端」。已有本机账号副本的设备可点「从云端恢复」。

云端记录保存在 `public.donezo_study`。数据库策略按账号 ID 限制读取、创建和更新。保存使用版本号防止旧副本覆盖新数据。项目里已经应用 [表结构与权限脚本](study-schema.sql)，迁移到另一个新项目时才需要执行该脚本。
