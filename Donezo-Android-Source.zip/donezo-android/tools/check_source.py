from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit
import xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1];assets=root/'app/src/main/assets'
missing=[]
class Check(HTMLParser):
    def __init__(self,path):super().__init__();self.path=path
    def handle_starttag(self,tag,attrs):
        for key,value in attrs:
            if key not in ('href','src') or not value or value.startswith(('#','data:','blob:')):continue
            u=urlsplit(value)
            if u.scheme or u.netloc:continue
            target=assets/u.path.lstrip('/') if u.path.startswith('/') else self.path.parent/u.path
            if not target.exists():missing.append((str(self.path),value))
for p in assets.rglob('*.html'):Check(p).feed(p.read_text())
assert not missing,missing
assert len(list(assets.glob('[0-9][0-9]-*/index.html')))==11
for p in (root/'app/src/main').rglob('*.xml'):ET.parse(p)
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
assert 'android.permission.READ_EXTERNAL_STORAGE' not in manifest
assert 'android.permission.MANAGE_EXTERNAL_STORAGE' not in manifest
assert (root/'.github/workflows/android.yml').is_file()
assert (root/'signing/development.keystore').is_file()
print('OK: 11 screens; HTML resource paths; XML; workflow; development signing key.')
