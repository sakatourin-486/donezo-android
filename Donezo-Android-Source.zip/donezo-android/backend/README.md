# Donezo 后端与 QQ 邮箱验证码

## 开通 QQ 邮箱发信

1. 用浏览器登录 [QQ 邮箱网页版](https://mail.qq.com/)，进入设置里的账号或邮箱协议服务页面，找到 **POP3/IMAP/SMTP 服务**。
2. 开启包含 SMTP 的服务，按页面提示完成验证并生成**授权码**。
3. 把完整的 QQ 邮箱地址填到服务器的 `.env` 中的 `SMTP_USER`，把授权码填到 `SMTP_AUTH_CODE`。授权码只留在服务器上。
4. Donezo 通过 `smtp.qq.com:465` 使用 TLS 发验证码邮件。登录者填写自己能收信的邮箱，QQ 邮箱用作发件人。

## 启动服务

使用 Node.js 24 或更新版本。在服务器进入 `backend/`：

```sh
npm ci
cp .env.example .env
node -e "console.log(require('node:crypto').randomBytes(32).toString('hex'))"
```

把生成的值填入 `OTP_SECRET`，写好发件邮箱和授权码后运行 `npm start`。服务默认监听 `127.0.0.1:8787`。使用 HTTPS 反向代理提供外部访问，安卓端填入 HTTPS 根地址，例如 `https://api.example.com`。如果反向代理与服务位于同一台机器，且代理会覆盖 `X-Real-IP` 为真实客户端地址，可设置 `TRUST_LOCAL_PROXY=1` 以按客户端 IP 限流。

运行 `curl https://你的后端域名/health`，应收到 `{"ok":true}`。打开 App 的「个人中心 → 邮箱注册 / 登录」，填后端地址和收件邮箱，点「发送验证码」。首次验证成功后自动建号。

现有本机数据可通过「导入本机记录」复制，之后点「保存到云端」。新设备首次登录会加载已保存的云端记录。已有本机账号副本的设备可选择「从云端恢复」。云端同步覆盖学科、任务、目标与学习记录，按整份记录的版本检查冲突。

SQLite 文件默认保存在 `data/donezo.sqlite`。部署时将该目录放在持久化磁盘上。

## 本机测试

设置 `MAIL_MODE=local-test` 和至少 32 字符的 `OTP_SECRET`，运行 `npm start`。测试验证码只打印在本机终端。测试模式只允许监听回环地址且禁止信任代理。运行 `npm test` 可验证验证码和云端存取流程。
