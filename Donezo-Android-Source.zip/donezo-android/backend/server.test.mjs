import test from 'node:test';
import assert from 'node:assert/strict';
import {once} from 'node:events';
import {mkdtempSync,rmSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {DatabaseSync} from 'node:sqlite';
import {createBackend} from './server.mjs';

test('email verification, session revocation and isolated learning records',async () => {
  const directory = mkdtempSync(join(tmpdir(),'donezo-backend-'));
  const dbPath = join(directory,'test.sqlite');
  const delivered = new Map();
  const server = createBackend({
    dbPath,secret:'a'.repeat(64),
    sendEmail:async (email,code)=>delivered.set(email,code)
  });
  try {
    server.listen(0,'127.0.0.1');
    await once(server,'listening');
    const base = 'http://127.0.0.1:'+server.address().port;
    async function request(path,{method='GET',body,token}={}) {
      const headers = {};
      if(body)headers['Content-Type']='application/json';
      if(token)headers.Authorization='Bearer '+token;
      const response = await fetch(base+path,{method,headers,body:body&&JSON.stringify(body)});
      return {status:response.status,data:await response.json()};
    }
    const send = email=>request('/v1/auth/send-code',{method:'POST',body:{email}});
    const verify = (email,code)=>request('/v1/auth/verify',{method:'POST',body:{email,code}});
    const email = 'first@example.test';
    assert.equal((await send('a@example.test\nb@example.test')).status,400);
    assert.equal((await send('FIRST@example.test')).status,200);
    assert.equal((await send(email)).status,429);
    const code = delivered.get(email);
    assert.match(code,/^\d{6}$/);
    assert.equal((await verify(email,code==='000000'?'000001':'000000')).status,400);
    const login = await verify(email,code);
    assert.equal(login.status,200);
    assert.equal(login.data.maskedEmail,'fi***@example.test');
    assert.equal((await verify(email,code)).status,400);
    const token = login.data.token;
    const data = {subjects:['物理'],tasks:[],goals:[],logs:[{
      id:'log-one',title:'平抛运动',date:'2026-11-07',note:'复盘',minutes:25
    }]};
    const put = (revision, data) => request('/v1/study',{method:'PUT',body:{revision,data},token});
    assert.equal((await request('/v1/study')).status,401);
    assert.deepEqual((await put(0,data)).data,{revision:1});
    assert.deepEqual((await put(0,data)).data,{revision:1},'retry is idempotent');
    assert.equal((await put(0,{...data,logs:[]})).status,409);
    const other = 'second@example.test';
    assert.equal((await send(other)).status,200);
    const second = await verify(other,delivered.get(other));
    assert.deepEqual((await request('/v1/study',{token:second.data.token})).data,{revision:0,data:null});
    assert.equal((await request('/v1/auth/logout',{method:'POST',token})).status,200);
    assert.equal((await request('/v1/study',{token})).status,401);
    const db = new DatabaseSync(dbPath);
    db.prepare('UPDATE challenges SET sent=sent-61 WHERE email=?').run(email);
    db.close();
    assert.equal((await send(email)).status,200);
    const reLogin = await verify(email,delivered.get(email));
    assert.equal(reLogin.status,200);
    assert.equal(reLogin.data.accountId,login.data.accountId);
    assert.deepEqual((await request('/v1/study',{token:reLogin.data.token})).data,{revision:1,data});
  } finally {
    if(server.listening)await new Promise((resolve,reject)=>server.close(error=>error?reject(error):resolve()));
    rmSync(directory,{recursive:true,force:true});
  }
});
