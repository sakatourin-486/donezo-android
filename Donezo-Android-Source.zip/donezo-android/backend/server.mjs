import {createServer} from 'node:http';
import {createHash, createHmac, randomBytes, randomInt, randomUUID, timingSafeEqual} from 'node:crypto';
import {DatabaseSync} from 'node:sqlite';
import {isIP} from 'node:net';
import {mkdirSync} from 'node:fs';
import {dirname, resolve} from 'node:path';
import {pathToFileURL} from 'node:url';

const otpSeconds = 300;
const cooldown = 60;
const bodyLimit = 1024 * 1024;
const localHosts = new Set(['127.0.0.1', '::1', '::ffff:127.0.0.1']);
const hash = value => createHash('sha256').update(value).digest('hex');
const emailOf = value => {
  const email = typeof value === 'string' ? value.trim().toLowerCase() : '';
  const [local] = email.split('@');
  const valid = email.length <= 254 && local.length <= 64 &&
    /^[a-z0-9_+%-]+(?:\.[a-z0-9_+%-]+)*@[a-z0-9]+(?:[a-z0-9-]*[a-z0-9])?(?:\.[a-z0-9]+(?:[a-z0-9-]*[a-z0-9])?)+$/.test(email);
  if (!valid) throw new ApiError(400, '请输入有效的邮箱地址');
  return email;
};
const maskEmail = email => {
  const [local,domain] = email.split('@');
  return local.slice(0,2)+'***@'+domain;
};

class ApiError extends Error {
  constructor(status, message, retryAfter) {
    super(message);
    this.status = status;
    this.retryAfter = retryAfter;
  }
}

async function readJson(req) {
  if (!/^application\/json(?:;|$)/i.test(req.headers['content-type'] || '')) {
    throw new ApiError(415, '请求必须使用 JSON');
  }
  const chunks = [];
  let size = 0;
  for await (const chunk of req.iterator({destroyOnReturn:false})) {
    size += chunk.length;
    if (size > bodyLimit) {
      req.resume();
      throw new ApiError(413, '学习数据超过 1 MB');
    }
    chunks.push(chunk);
  }
  try {
    const value = JSON.parse(Buffer.concat(chunks).toString('utf8'));
    if (!object(value)) throw new Error();
    return value;
  } catch { throw new ApiError(400, 'JSON 格式错误'); }
}

const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const str = value => typeof value === 'string';
const id = value => str(value) && /^[\w-]{1,128}$/.test(value);
const list = (value, predicate) => Array.isArray(value) && value.every(predicate);
const record = item => object(item) && id(item.id);
const completed = item => object(item) && str(item.title) && typeof item.done === 'boolean';
function validateData(data) {
  const valid = object(data) &&
    list(data.subjects, str) &&
    list(data.tasks, t => record(t) && completed(t) && str(t.subject) && str(t.date) &&
      str(t.start) && str(t.end) && str(t.priority) && str(t.note) && list(t.subtasks, completed)) &&
    list(data.goals, g => record(g) && str(g.title) && str(g.subject) && str(g.deadline) &&
      list(g.chapters, c => record(c) && completed(c) && str(c.category))) &&
    list(data.logs, l => record(l) && str(l.title) && str(l.date) && str(l.note) &&
      Number.isFinite(l.minutes) && l.minutes >= 0 && (l.goal === '' || l.goal == null || id(l.goal)));
  if (!valid) throw new ApiError(400, '学习数据字段不完整');
  return JSON.stringify({subjects:data.subjects,tasks:data.tasks,goals:data.goals,logs:data.logs});
}

export function createBackend({dbPath, secret, sendEmail, origins = ['https://appassets.androidplatform.net'], trustLocalProxy = false}) {
  if (typeof secret !== 'string' || secret.length < 32) throw new Error('OTP_SECRET must contain at least 32 characters');
  const db = new DatabaseSync(dbPath);
  db.exec(`
    PRAGMA journal_mode=WAL;
    PRAGMA foreign_keys=ON;
    PRAGMA busy_timeout=3000;
    CREATE TABLE IF NOT EXISTS accounts (id TEXT PRIMARY KEY, email TEXT NOT NULL UNIQUE);
    CREATE TABLE IF NOT EXISTS sessions (
      digest TEXT PRIMARY KEY, account_id TEXT NOT NULL REFERENCES accounts(id), expires INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS sessions_expiry ON sessions(expires);
    CREATE TABLE IF NOT EXISTS challenges (
      email TEXT PRIMARY KEY, nonce TEXT NOT NULL, digest TEXT NOT NULL,
      sent INTEGER NOT NULL, expires INTEGER NOT NULL, ready INTEGER NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS limits (scope TEXT NOT NULL, stamp INTEGER NOT NULL);
    CREATE INDEX IF NOT EXISTS limits_scope_stamp ON limits(scope, stamp);
    CREATE INDEX IF NOT EXISTS limits_stamp ON limits(stamp);
    CREATE TABLE IF NOT EXISTS snapshots (
      account_id TEXT PRIMARY KEY REFERENCES accounts(id), revision INTEGER NOT NULL, payload TEXT NOT NULL
    );
  `);
  const now = () => Math.floor(Date.now()/1000);
  const otpHash = (email, nonce, code) => createHmac('sha256',secret).update(`${email}:${nonce}:${code}`).digest();
  function transaction(fn) {
    db.exec('BEGIN IMMEDIATE');
    try {
      const result = fn();
      db.exec('COMMIT');
      return result;
    } catch (error) {
      db.exec('ROLLBACK');
      throw error;
    }
  }
  function rate(scope, max, seconds, stamp) {
    const row = db.prepare('SELECT COUNT(*) AS count, MIN(stamp) AS oldest FROM limits WHERE scope=? AND stamp>?')
      .get(scope, stamp-seconds);
    if (row.count >= max) throw new ApiError(429, '操作太频繁，请稍后重试', row.oldest+seconds-stamp);
    db.prepare('INSERT INTO limits (scope,stamp) VALUES (?,?)').run(scope,stamp);
  }
  function senderIp(req) {
    const address = req.socket.remoteAddress || 'unknown';
    const forwarded = req.headers['x-real-ip'];
    return trustLocalProxy && localHosts.has(address) && typeof forwarded === 'string' && isIP(forwarded)
      ? forwarded : address;
  }
  function authenticate(req) {
    const token = req.headers.authorization?.match(/^Bearer ([a-zA-Z0-9_-]{43})$/)?.[1];
    const digest = token && hash(token);
    const session = digest && db.prepare('SELECT account_id FROM sessions WHERE digest=? AND expires>?').get(digest,now());
    if (!session) throw new ApiError(401,'登录已失效，请重新登录');
    return {id:session.account_id,digest};
  }

  async function route(req) {
    const path = req.url?.split('?')[0];
    if (req.method === 'GET' && path === '/health') return {ok:true};
    if (req.method === 'POST' && path === '/v1/auth/send-code') {
      const email = emailOf((await readJson(req)).email);
      const stamp = now();
      const code = String(randomInt(0,1_000_000)).padStart(6,'0');
      const nonce = randomBytes(16).toString('hex');
      transaction(() => {
        const previous = db.prepare('SELECT sent FROM challenges WHERE email=?').get(email);
        if (previous && previous.sent+cooldown > stamp) throw new ApiError(429,'请稍后重新获取验证码',previous.sent+cooldown-stamp);
        rate('send:global',120,3600,stamp);
        rate('send:ip:'+senderIp(req),15,3600,stamp);
        rate('send:email:'+email,5,3600,stamp);
        db.prepare(`INSERT INTO challenges(email,nonce,digest,sent,expires,ready) VALUES(?,?,?,?,?,0)
          ON CONFLICT(email) DO UPDATE SET nonce=excluded.nonce,digest=excluded.digest,
          sent=excluded.sent,expires=excluded.expires,ready=0`)
          .run(email,nonce,otpHash(email,nonce,code).toString('hex'),stamp,stamp+otpSeconds);
      });
      try { await sendEmail(email, code); }
      catch {
        console.error('SMTP delivery failed');
        throw new ApiError(502,'验证码暂时发送失败，请稍后重试');
      }
      db.prepare('UPDATE challenges SET ready=1 WHERE email=? AND nonce=?').run(email,nonce);
      return {retryAfter:cooldown,expiresIn:otpSeconds};
    }
    if (req.method === 'POST' && path === '/v1/auth/verify') {
      const {email:raw,code} = await readJson(req);
      const email = emailOf(raw);
      if (!str(code) || !/^\d{6}$/.test(code)) throw new ApiError(400,'请输入六位验证码');
      const stamp = now();
      const session = transaction(() => {
        rate('verify:ip:'+senderIp(req),45,3600,stamp);
        rate('verify:email:'+email,5,otpSeconds,stamp);
        const challenge = db.prepare('SELECT * FROM challenges WHERE email=?').get(email);
        const digest = otpHash(email,challenge?.nonce || '',code);
        const expected = Buffer.from(challenge?.digest || '0'.repeat(64),'hex');
        const matched = timingSafeEqual(digest,expected);
        if (!matched || !challenge?.ready || challenge.expires <= stamp) return null;
        // Retain the send cooldown even after consuming the challenge.
        db.prepare('UPDATE challenges SET ready=0 WHERE email=?').run(email);
        db.prepare('INSERT INTO accounts (id,email) VALUES (?,?) ON CONFLICT(email) DO NOTHING').run(randomUUID(),email);
        const account = db.prepare('SELECT id FROM accounts WHERE email=?').get(email);
        const token = randomBytes(32).toString('base64url');
        db.prepare('INSERT INTO sessions(digest,account_id,expires) VALUES (?,?,?)').run(hash(token),account.id,stamp+30*86400);
        return {token,accountId:account.id,maskedEmail:maskEmail(email)};
      });
      if (!session) throw new ApiError(400,'验证码错误、已用过或已过期');
      return session;
    }
    if (req.method === 'POST' && path === '/v1/auth/logout') {
      db.prepare('DELETE FROM sessions WHERE digest=?').run(authenticate(req).digest);
      return {ok:true};
    }
    if (path === '/v1/study' && req.method === 'GET') {
      const account = authenticate(req);
      const row = db.prepare('SELECT revision,payload FROM snapshots WHERE account_id=?').get(account.id);
      return row ? {revision:row.revision,data:JSON.parse(row.payload)} : {revision:0,data:null};
    }
    if (path === '/v1/study' && req.method === 'PUT') {
      const {revision,data} = await readJson(req);
      const account = authenticate(req);
      if (!Number.isSafeInteger(revision) || revision < 0) throw new ApiError(400,'同步版本无效');
      const payload = validateData(data);
      return transaction(() => {
        const row = db.prepare('SELECT revision,payload FROM snapshots WHERE account_id=?').get(account.id);
        if (row?.payload === payload) return {revision:row.revision};
        if ((row?.revision || 0) !== revision) throw new ApiError(409,'云端已更新，请先查看云端数据');
        db.prepare(`INSERT INTO snapshots(account_id,revision,payload) VALUES(?,?,?)
          ON CONFLICT(account_id) DO UPDATE SET revision=excluded.revision,payload=excluded.payload`)
          .run(account.id,revision+1,payload);
        return {revision:revision+1};
      });
    }
    throw new ApiError(404,'接口不存在');
  }

  const server = createServer(async (req,res) => {
    res.setHeader('Cache-Control','no-store');
    res.setHeader('Vary','Origin');
    res.setHeader('Content-Type','application/json; charset=utf-8');
    const origin = req.headers.origin;
    try {
      if (origin && !origins.includes(origin)) throw new ApiError(403,'来源未获准访问');
      if (origin) res.setHeader('Access-Control-Allow-Origin',origin);
      if (req.method === 'OPTIONS') {
        res.writeHead(204,{'Access-Control-Allow-Methods':'GET,POST,PUT,OPTIONS','Access-Control-Allow-Headers':'Authorization,Content-Type'});
        return res.end();
      }
      res.end(JSON.stringify(await route(req)));
    } catch (error) {
      if (!(error instanceof ApiError)) console.error('Request failed:',error.name);
      res.statusCode = error instanceof ApiError ? error.status : 500;
      if (error.retryAfter) res.setHeader('Retry-After',String(error.retryAfter));
      res.end(JSON.stringify({error:error instanceof ApiError ? error.message : '服务暂时不可用',retryAfter:error.retryAfter}));
    }
  });
  const cleanup = setInterval(() => {
    const stamp = now();
    db.prepare('DELETE FROM limits WHERE stamp<?').run(stamp-3600);
    db.prepare('DELETE FROM challenges WHERE expires<?').run(stamp);
    db.prepare('DELETE FROM sessions WHERE expires<?').run(stamp);
  },600_000);
  cleanup.unref();
  server.once('close',() => {clearInterval(cleanup);db.close()});
  return server;
}

async function start() {
  const env = process.env;
  const host = env.HOST || '127.0.0.1';
  let sendEmail;
  if (env.MAIL_MODE === 'local-test') {
    if (!localHosts.has(host) || env.TRUST_LOCAL_PROXY === '1') throw new Error('Local test mode requires loopback without a proxy');
    sendEmail = async (email,code) => console.log(`[本地测试] ${maskEmail(email)} 的验证码为 ${code}`);
  } else {
    if (!env.SMTP_USER || !env.SMTP_AUTH_CODE) throw new Error('请配置 QQ 邮箱账号和 SMTP 授权码，或使用 MAIL_MODE=local-test');
    const from = emailOf(env.SMTP_USER);
    if (!from.endsWith('@qq.com')) throw new Error('SMTP_USER 应填写完整的 QQ 邮箱地址');
    const {default:nodemailer} = await import('nodemailer');
    const smtp = nodemailer.createTransport({
      host:'smtp.qq.com',port:465,secure:true,
      auth:{user:from,pass:env.SMTP_AUTH_CODE},
      connectionTimeout:7000,greetingTimeout:7000,socketTimeout:10000,
      disableFileAccess:true,disableUrlAccess:true
    });
    sendEmail = async (email,code) => {
      await smtp.sendMail({
        from:{name:'Donezo 学记',address:from},
        to:{address:email},
        subject:'Donezo 登录验证码',
        text:`你的 Donezo 登录验证码为 ${code}。请在 5 分钟内使用。请勿向他人提供此验证码。`
      });
    };
  }
  const dbPath = resolve(env.DB_PATH || 'data/donezo.sqlite');
  mkdirSync(dirname(dbPath),{recursive:true,mode:0o700});
  const origins = ['https://appassets.androidplatform.net',...(env.EXTRA_ORIGINS || '').split(',').map(v=>v.trim()).filter(Boolean)];
  createBackend({dbPath,secret:env.OTP_SECRET,sendEmail,origins,trustLocalProxy:env.TRUST_LOCAL_PROXY==='1'})
    .listen(Number(env.PORT || 8787),host,() => console.log('Donezo backend is ready'));
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  start().catch(error=>{console.error(error.message);process.exitCode=1});
}
