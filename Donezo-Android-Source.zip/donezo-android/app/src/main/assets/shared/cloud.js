(() => {
  const guestKey = 'donezo-state-v1';
  const sessionKey = 'donezo-cloud-session-v1';
  const endpointKey = 'donezo-cloud-endpoint';
  const studyFields = ['subjects', 'tasks', 'goals', 'logs'];
  const read = key => JSON.parse(localStorage.getItem(key) || 'null');
  const session = () => read(sessionKey);
  const accountKey = id => guestKey + ':account:' + id;
  const stateKey = () => session() ? accountKey(session().accountId) : guestKey;
  const revisionKey = account => accountKey(account.accountId) + ':revision';
  const pickStudy = value => Object.fromEntries(studyFields.map(key => [key,value[key]]));

  function endpoint(value) {
    let url;
    try { url = new URL(value.trim()); }
    catch { throw Error('请输入后端 HTTPS 地址'); }
    const loopback = ['localhost','127.0.0.1','[::1]'].includes(url.hostname);
    if (url.username || url.password || url.pathname !== '/' || url.search || url.hash ||
      !(url.protocol === 'https:' || (loopback && url.protocol === 'http:'))) {
      throw Error('请填写后端的 HTTPS 根地址');
    }
    return url.origin;
  }

  async function request(base, path, {method='GET', body, token} = {}) {
    const headers = {};
    if (body) headers['Content-Type'] = 'application/json';
    if (token) headers.Authorization = 'Bearer ' + token;
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(),15000);
    try {
      const response = await fetch(base + path,{
        method,headers,credentials:'omit',redirect:'error',signal:controller.signal,
        body:body ? JSON.stringify(body) : undefined
      });
      const data = await response.json();
      if (!response.ok) throw Object.assign(Error(data.error || '请求失败'),{
        status:response.status,retryAfter:data.retryAfter
      });
      return data;
    } catch (error) {
      if (error instanceof TypeError || error.name === 'AbortError') throw Error('无法连接后端，请检查地址和网络');
      throw error;
    } finally { clearTimeout(timeout); }
  }

  function signedIn() {
    const account = session();
    if (!account) throw Error('请先登录');
    return account;
  }

  async function login(address, email, code, initialState) {
    const base = endpoint(address);
    const account = {...await request(base,'/v1/auth/verify',{method:'POST',body:{email,code}}),base};
    const snapshot = await request(base,'/v1/study',{token:account.token});
    const key = accountKey(account.accountId);
    if (!read(key)) {
      const initial = snapshot.data ? {...initialState,...snapshot.data} : initialState;
      localStorage.setItem(key,JSON.stringify(initial));
      localStorage.setItem(revisionKey(account),String(snapshot.revision));
    }
    localStorage.setItem(endpointKey,base);
    localStorage.setItem(sessionKey,JSON.stringify(account));
  }

  async function logout() {
    const account = signedIn();
    try { await request(account.base,'/v1/auth/logout',{method:'POST',token:account.token}); }
    catch (error) { if (error.status !== 401) throw error; }
    localStorage.removeItem(sessionKey);
  }

  async function upload(value) {
    const account = signedIn();
    const revision = Number(localStorage.getItem(revisionKey(account)) || 0);
    const saved = await request(account.base,'/v1/study',{
      method:'PUT',token:account.token,body:{revision,data:pickStudy(value)}
    });
    localStorage.setItem(revisionKey(account),String(saved.revision));
  }

  async function download() {
    const account = signedIn();
    const snapshot = await request(account.base,'/v1/study',{token:account.token});
    if (!snapshot.data) throw Error('云端还没有学习记录');
    return snapshot;
  }

  window.DonezoCloud = {
    session,stateKey,login,logout,upload,download,pickStudy,
    guest:() => read(guestKey),
    lastEndpoint:() => localStorage.getItem(endpointKey) || '',
    sendCode:(address,email) => request(endpoint(address),'/v1/auth/send-code',{method:'POST',body:{email}}),
    acceptRevision:revision => localStorage.setItem(revisionKey(signedIn()),String(revision))
  };
})();
