(() => {
  const client = window.supabase.createClient(
    'https://kifuczvkkfayaqfneqno.supabase.co',
    'sb_publishable_Bln1uopsKhSkEYzkVlAXGQ_FkMGbm0x',
    {auth:{detectSessionInUrl:false}}
  );
  const guestKey = 'donezo-state-v1';
  const sessionKey = 'donezo-supabase-account-v1';
  const studyFields = ['subjects', 'tasks', 'goals', 'logs'];
  const read = key => JSON.parse(localStorage.getItem(key) || 'null');
  const session = () => read(sessionKey);
  const accountKey = id => guestKey + ':account:' + id;
  const stateKey = () => {
    const account = session();
    return account ? accountKey(account.accountId) : guestKey;
  };
  const revisionKey = account => accountKey(account.accountId) + ':revision';
  const pickStudy = value => Object.fromEntries(studyFields.map(key => [key,value[key]]));
  const table = () => client.from('donezo_study');

  function checked({data,error}) {
    if (error) {
      const message = {
        email_address_not_authorized:'这个邮箱尚未获准收信。测试时请用 Supabase 项目团队成员的邮箱。',
        over_email_send_rate_limit:'发信次数过多，请稍后重试。',
        over_request_rate_limit:'请求太频繁，请稍后重试。',
        otp_expired:'验证码无效或已过期，请重新获取。',
        session_not_found:'登录已过期，请重新登录。',
        bad_jwt:'登录已过期，请重新登录。'
      }[error.code];
      throw Error(message || error.message || '云端操作失败');
    }
    return data;
  }

  async function currentAccount() {
    const account = session();
    const auth = checked(await client.auth.getSession()).session;
    if (!account || auth?.user?.id !== account.accountId) throw Error('请重新登录云端账号');
    return account;
  }

  async function snapshot(id) {
    const row = checked(await table().select('revision,data').eq('user_id',id).maybeSingle());
    return row || {revision:0,data:null};
  }

  async function sendCode(email) {
    checked(await client.auth.signInWithOtp({
      email:email.trim().toLowerCase(),options:{shouldCreateUser:true}
    }));
  }

  async function login(email, code, initialState) {
    const auth = checked(await client.auth.verifyOtp({
      email:email.trim().toLowerCase(),token:code.trim(),type:'email'
    }));
    if (!auth.user || !auth.session) throw Error('登录未完成，请重新获取验证码');
    const [name,domain] = auth.user.email.split('@');
    const account = {accountId:auth.user.id,maskedEmail:name.slice(0,2)+'***@'+domain};
    try {
      const key = accountKey(account.accountId);
      if (!read(key)) {
        const remote = await snapshot(account.accountId);
        const initial = remote.data ? {...initialState,...pickStudy(remote.data)} : initialState;
        localStorage.setItem(key,JSON.stringify(initial));
        localStorage.setItem(revisionKey(account),String(remote.revision));
      }
      localStorage.setItem(sessionKey,JSON.stringify(account));
    } catch(error) {
      await client.auth.signOut({scope:'local'});
      throw error;
    }
  }

  async function logout() {
    checked(await client.auth.signOut({scope:'local'}));
    localStorage.removeItem(sessionKey);
  }

  async function upload(value) {
    const account = await currentAccount();
    const revision = Number(localStorage.getItem(revisionKey(account)) || 0);
    const row = {data:pickStudy(value),revision:revision+1};
    const query = revision === 0
      ? table().insert({...row,user_id:account.accountId})
      : table().update(row).eq('user_id',account.accountId).eq('revision',revision);
    const result = await query.select('revision').maybeSingle();
    if (result.error?.code === '23505' || (!result.error && !result.data)) {
      throw Error('云端记录已被更新，请先从云端恢复，再重新保存。');
    }
    localStorage.setItem(revisionKey(account),String(checked(result).revision));
  }

  async function download() {
    const account = await currentAccount();
    const remote = await snapshot(account.accountId);
    if (!remote.data) throw Error('云端还没有学习记录');
    return remote;
  }

  window.DonezoCloud = {
    session,stateKey,sendCode,login,logout,upload,download,pickStudy,
    guest:() => read(guestKey),
    acceptRevision:revision => {
      const account = session();
      if (!account) throw Error('请先登录');
      localStorage.setItem(revisionKey(account),String(revision));
    }
  };
})();
