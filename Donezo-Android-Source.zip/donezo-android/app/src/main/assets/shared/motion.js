(() => {
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const all = selector => [...document.querySelectorAll(selector)];
  const metricSelector = [
    '[data-page="today-analysis"] [data-count]',
    '[data-page="04-dashboard"] main .text-metric-xl',
    '[data-page="04-dashboard"] main .text-metric-lg',
    '.dz-task-count,.dz-progress-number',
    '[data-page="11-mobile-dashboard"] section[aria-label="核心指标"] .text-metric-lg',
    '[data-page="02-goal-detail"] main .text-metric-xl',
    '[data-page="07-study-group"] main .text-metric-lg'
  ].join(',');
  const ringSelector = 'main svg path[stroke-dashoffset], main circle[stroke-dashoffset]';
  const barSelector = '[data-page="04-dashboard"] main .h-44>div>div,[data-page="02-goal-detail"] main .h-36>div>div';
  const markSelector = '.dz-check[aria-checked],[data-chapter] [role="checkbox"],[data-group-toggle]';
  const mark = '<svg class="dz-mark" width="16" height="16" viewBox="0 0 20 20" aria-hidden="true"><path pathLength="1" d="M4.5 10.4 8.1 14 15.8 6.2"/></svg>';
  const metricPattern = /^(-?\d+(?:\.\d+)?)(%|\s*\/\s*\d+)?$/;
  const timerPattern = /^(\d+):(\d\d):(\d\d)$/;

  function snapshot() {
    return {
      values: new Map(all(metricSelector).map(el => [el, el.textContent.trim()])),
      rings: new Map(all(ringSelector).map(el => [el, +el.getAttribute('stroke-dashoffset')])),
      bars: new Map(all(barSelector).map(el => [el, el.getBoundingClientRect().height])),
      fills: new Map(all('.dz-progress-fill').map(el => [el,parseFloat(el.style.width)]))
    };
  }

  function metrics(before) {
    if (reduced.matches || !window.gsap) return;
    for (const el of all(metricSelector)) {
      const value = el.textContent.trim();
      const number = metricPattern.exec(value);
      el.dzCountTween?.kill();
      if (!number) continue;
      const end = Number(number[1]);
      const start = Number(metricPattern.exec(before?.values.get(el) || '')?.[1] || 0);
      const decimals = number[1].split('.')[1]?.length || 0;
      if (start === end) continue;
      const counter = {value:start};
      const tween = gsap.to(counter, {
        value:end, duration:.65, ease:'power2.out',
        onUpdate:() => el.textContent = counter.value.toFixed(decimals) + (number[2]||''),
        onComplete:() => el.textContent = value
      });
      el.dzCountTween = tween;
      el.textContent = start.toFixed(decimals) + (number[2]||'');
    }

    for (const el of all(ringSelector)) {
      const end = +el.getAttribute('stroke-dashoffset');
      const start = before?.rings.get(el) ?? parseFloat(el.getAttribute('stroke-dasharray'));
      if (Number.isFinite(start) && start !== end) {
        gsap.fromTo(el, {attr:{'stroke-dashoffset':start}}, {
          attr:{'stroke-dashoffset':end}, duration:.65, ease:'power2.out', overwrite:true
        });
      }
    }

    for (const el of all('.dz-progress-fill')) {
      const end = parseFloat(el.style.width);
      const start = before?.fills.get(el) || 0;
      if (Number.isFinite(end) && start !== end) {
        gsap.fromTo(el,{width:start+'%'},{width:end+'%',duration:.65,ease:'power2.out',overwrite:true});
      }
    }

    all(barSelector).forEach((el, i) => {
      const height = el.getBoundingClientRect().height;
      const previous = before?.bars.get(el) || 0;
      if (height && Math.abs(height-previous) > .5) {
        gsap.fromTo(el, {scaleY:previous/height, transformOrigin:'bottom'}, {
          scaleY:1, duration:.47, delay:before ? 0 : i*.04, ease:'power2.out',
          overwrite:true, clearProps:'transform,transformOrigin'
        });
      }
    });
  }

  function completionElements() {
    const found = new Map();
    for (const el of all(markSelector)) {
      const row = el.closest('[data-chapter],.dz-list-card,.dz-row') || el.parentElement.parentElement;
      const identity = el.dataset.toggle || el.dataset.groupToggle || row.dataset.chapter
        || el.dataset.taskSub || el.dataset.sub;
      const kind = el.hasAttribute('data-task-sub') ? 'panel' : el.hasAttribute('data-sub') ? 'dialog' : 'row';
      const title = row.querySelector('.dz-task-title,.truncate') || el.nextElementSibling;
      const key = `${kind}:${identity}:${title?.textContent.trim() || ''}`;
      found.set(key, {el, title, done:el.getAttribute('aria-checked') === 'true'});
    }
    for (const el of all('.dz-event[data-completion]')) {
      found.set('event:'+el.dataset.completion, {title:el, done:el.dataset.done === 'true'});
    }
    return found;
  }

  function completionSnapshot() {
    return new Map([...completionElements()].map(([key, item]) => {
      const mark = item.el?.querySelector('.dz-mark path');
      return [key, {
        done:item.done,
        offset:mark ? parseFloat(mark.style.strokeDashoffset) : item.done ? 0 : 1,
        strike:item.title?.querySelector('.dz-strike-ink')?.style.getPropertyValue('--dz-strike') || (item.done ? '100%' : '0%'),
        focused:document.activeElement === item.el
      }];
    }));
  }

  function completion(before = new Map()) {
    const animate = window.gsap && !reduced.matches;
    for (const [key, {el,title,done}] of completionElements()) {
      const previous = before.get(key);
      const changed = previous && previous.done !== done;
      const offset = done ? 0 : 1;
      const width = done ? '100%' : '0%';
      if (title) {
        title.classList.add('dz-strike');
        let ink = title.querySelector('.dz-strike-ink');
        if (!ink) {
          ink = document.createElement('span');
          ink.className = 'dz-strike-ink';
          ink.textContent = title.textContent;
          title.replaceChildren(ink);
        }
        ink.style.setProperty('--dz-strike', width);
        if (changed && animate) gsap.fromTo(ink, {'--dz-strike':previous.strike}, {
          '--dz-strike':width, duration:.29, delay:done ? .06 : 0, ease:'power2.out', overwrite:true
        });
      }
      if (!el) continue;
      el.classList.add('dz-check-motion');
      if (el.dataset.groupToggle) el.setAttribute('role','checkbox');
      if (!el.querySelector('.dz-mark')) el.innerHTML = mark;
      const path = el.querySelector('.dz-mark path');
      path.style.strokeDashoffset = offset;
      if (changed && animate) {
        const bg = done ? '#144734' : '#fff';
        const oldBg = done ? '#fff' : '#144734';
        gsap.timeline({defaults:{overwrite:'auto'}})
          .fromTo(el,{'--dz-check-bg':oldBg,scale:1},
            {'--dz-check-bg':bg,scale:.88,duration:.12})
          .to(el,{scale:1,duration:.26,ease:'back.out(2)',clearProps:'transform'})
          .call(()=>el.style.removeProperty('--dz-check-bg'));
        gsap.fromTo(path,{strokeDashoffset:previous.offset,stroke:'white'},
          {strokeDashoffset:offset,stroke:done?'white':'#144734',duration:.25,ease:'power2.out',overwrite:true,clearProps:'stroke'});
      }
      if (previous?.focused && document.activeElement === document.body) el.focus({preventScroll:true});
    }
  }

  const sliders = new WeakMap();

  function selection(group, target, animated = true) {
    let state = sliders.get(group);
    if (!state) {
      const marker = document.createElement('span');
      marker.className = 'dz-selection-marker';
      marker.setAttribute('aria-hidden', 'true');
      state = {marker, target:null};
      sliders.set(group, state);
      new ResizeObserver(() => selection(group, state.target, false)).observe(group);
    }
    const {marker} = state;
    if (marker.parentNode !== group) group.prepend(marker);
    const previous = state.target;
    state.target = target;
    if (!target) {
      marker.hidden = true;
      return;
    }
    marker.hidden = false;
    const bounds = group.getBoundingClientRect();
    const item = target.getBoundingClientRect();
    const geometry = {
      x:item.left-bounds.left-group.clientLeft+group.scrollLeft,
      y:item.top-bounds.top-group.clientTop+group.scrollTop,
      width:item.width,
      height:item.height
    };
    marker.style.borderRadius = getComputedStyle(target).borderRadius;
    if (window.gsap) {
      if (animated && previous && !reduced.matches) {
        gsap.to(marker,{...geometry,duration:.21,ease:'power2.out',overwrite:true});
      } else {
        gsap.killTweensOf(marker);
        gsap.set(marker,geometry);
      }
    } else {
      marker.style.transform = `translate(${geometry.x}px, ${geometry.y}px)`;
      marker.style.width = geometry.width+'px';
      marker.style.height = geometry.height+'px';
    }
  }

  function calendar(before, after) {
    if (!window.gsap || reduced.matches || !before) return;
    const grid = document.querySelector('#dz-cal-grid');
    const monthChanged = before.period !== after.period;
    const dayChanged = before.date !== after.date;
    if (monthChanged) {
      gsap.fromTo(grid, {x:after.period > before.period ? 26 : -26, opacity:.87},
        {x:0, opacity:1, duration:.25, ease:'power2.out', overwrite:true, clearProps:'transform,opacity'});
    }
    const agenda = document.querySelector('#dz-day-events');
    if (agenda && (dayChanged || monthChanged || before.filter !== after.filter)) {
      gsap.fromTo(agenda,{y:7,opacity:.45},{y:0,opacity:1,duration:.26,ease:'power2.out',overwrite:true,clearProps:'transform,opacity'});
    }
  }

  function timer(el, next) {
    const value = el.textContent.trim();
    if (value === next || el.dzTimerTarget === next) return;
    const from = timerPattern.exec(value), to = timerPattern.exec(next);
    if (!from || !to || !window.gsap || reduced.matches) { el.textContent = next; return; }
    const total = parts => +parts[1]*3600 + +parts[2]*60 + +parts[3];
    const counter = {seconds:total(from)};
    el.dzTimerTarget = next;
    el.dzTimerTween?.kill();
    el.dzTimerTween = gsap.to(counter, {
      seconds:total(to),duration:.32,ease:'power2.out',
      onUpdate:() => {
        const seconds = Math.round(counter.seconds);
        el.textContent = [Math.floor(seconds/3600),Math.floor(seconds/60)%60,seconds%60]
          .map(n=>String(n).padStart(2,'0')).join(':');
      },
      onComplete:() => { el.dzTimerTarget = null; el.textContent = next; }
    });
  }

  window.DonezoMotion = {snapshot, metrics, completionSnapshot, completion, selection, calendar, timer};
})();
