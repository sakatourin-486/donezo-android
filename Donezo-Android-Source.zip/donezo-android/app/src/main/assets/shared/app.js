(()=>{'use strict';
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)],page=document.body.dataset.page;
const shell=window.parent===window?null:window.parent.DonezoShell,motion=window.DonezoMotion;
const cloud=shell?.cloud, stateKey=cloud?.stateKey() || 'donezo-state-v1';
const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const icon=x=>`<span class="material-symbols-outlined" aria-hidden="true">${x}</span>`,uid=()=>crypto.randomUUID(),today=()=>new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Shanghai'}).format(new Date()),dayPlus=(day,n)=>{let d=new Date(day+'T12:00:00');d.setDate(d.getDate()+n);return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`};
const dateMonth=d=>d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0');
const routes={today:'/today/',dashboard:'/04-dashboard/',tasks:'/10-tasks/',materials:'/06-materials/',goal:'/02-goal-detail/',logs:'/05-study-logs/',calendar:'/09-calendar/',group:'/07-study-group/',settings:'/03-settings/',account:'/01-account/',imports:'/import/',detail:'/08-material-detail/'};
const btn=(label,action,cls='')=>`<button type="button" class="dz-btn ${cls}" data-action="${action}">${label}</button>`;
const empty=(s,action,label)=>`<div class="dz-empty">${icon('auto_stories')}<p>${esc(s)}</p>${action?btn(label||'添加',action,'primary'):''}</div>`;
const seed=()=>({version:1,demo:true,profile:{name:'林墨',email:'linmo@example.com',bio:'计算机科学系 · 每一步，都算数'},settings:{hours:28,theme:'light',weekStart:'1',notifications:true},subjects:['高等数学','计算机408','大学英语','线性代数'],tasks:[
{id:'task-1',title:'复习计网第四章 IP 分片机制',subject:'计算机408',date:today(),start:'14:00',end:'15:30',priority:'高',done:false,note:'手算分片偏移量与总长度案例习题，梳理 DF/MF 标志位。',subtasks:[{title:'通读 MTU 与 IP 数据报分片字段定义',done:true},{title:'手算分片偏移量与总长度案例习题',done:false},{title:'梳理 Wireshark 抓包分片标记位',done:false}]},
{id:'task-2',title:'高数多元函数极值习题 8 道',subject:'高等数学',date:today(),start:'16:00',end:'17:15',priority:'中',done:false,note:'完成习题并整理易错点',subtasks:[]},
{id:'task-3',title:'六级听力真题 Section B 模考精听',subject:'大学英语',date:today(),start:'20:30',end:'21:15',priority:'中',done:false,note:'对照原文复盘',subtasks:[]},
{id:'task-4',title:'背诵 50 个考研高频学术词汇',subject:'大学英语',date:today(),start:'08:00',end:'08:30',priority:'低',done:true,note:'',subtasks:[]},
{id:'task-5',title:'特征值习题复盘',subject:'线性代数',date:dayPlus(today(),1),start:'16:30',end:'17:30',priority:'中',done:false,note:'',subtasks:[]},
{id:'task-6',title:'流水线冲突模拟分析',subject:'计算机408',date:'',start:'',end:'',priority:'中',done:false,note:'',subtasks:[]}],
goals:[{id:'goal-1',title:'2026 计算机考研 408 冲刺',subject:'计算机408',deadline:'2026-12-27',chapters:[{id:'ch-1',title:'线性表、顺序表与循环双向链表',category:'数据结构',done:true},{id:'ch-2',title:'二叉树遍历、线索化与平衡二叉树(AVL)',category:'数据结构',done:false},{id:'ch-3',title:'图的应用：Dijkstra 算法与 AOV 拓扑排序',category:'图论专题',done:false},{id:'ch-4',title:'存储层次结构与 Cache 映射',category:'组成原理',done:false}]}],
materials:[{id:'mat-1',name:'微积分考研重点讲义',type:'PDF',subject:'高等数学',note:'',favorite:false,sample:true},{id:'mat-2',name:'CET-6 高频词汇',type:'XLSX',subject:'大学英语',note:'',favorite:false,sample:true},{id:'mat-3',name:'算法与数据结构研读笔记',type:'笔记',subject:'计算机408',note:'',favorite:false,sample:true},{id:'mat-4',name:'线性代数真题精讲',type:'链接',subject:'线性代数',url:'https://www.bilibili.com',note:'',favorite:false,sample:true}],
logs:[{id:'log-1',date:today(),minutes:90,title:'二叉树遍历与平衡二叉树',note:'复盘旋转与指针调整，梳理 LL/RR/LR/RL。',goal:'goal-1',rating:'A'}],groups:[{id:'group-1',name:'算法分析与设计研讨组',description:'一起研究算法、整理讲义、拆解复杂问题。',members:['林墨','Alexandra Deff','Edwin Adenike'],tasks:[{id:'gt-1',title:'整理动态规划题解',done:false,owner:'林墨'},{id:'gt-2',title:'复核图论证明',done:true,owner:'Alexandra Deff'}]}],trash:[],timer:{running:false,elapsed:0,started:0}});
let state;try{state=JSON.parse(localStorage.getItem(stateKey))||seed()}catch{state=seed()}
let storageOK=true;function persist(){try{localStorage.setItem(stateKey,JSON.stringify(state));return true}catch{storageOK=false;toast('保存失败：浏览器存储空间不足。请先导出备份。',true);return false}}
if(!localStorage.getItem(stateKey))persist();
function toast(s,sticky=false,undo){$('.dz-toast')?.remove();const e=document.createElement('div');e.className='dz-toast';e.setAttribute('role',sticky?'alert':'status');e.innerHTML=`<span>${esc(s)}</span>${undo?'<button>撤销</button>':''}`;document.body.append(e);if(undo)$('button',e).onclick=()=>{undo();e.remove()};if(window.gsap&&!reduced())gsap.from(e,{autoAlpha:0,y:12,duration:.2});if(!sticky)setTimeout(()=>e.remove(),3800)}
const reduced=()=>matchMedia('(prefers-reduced-motion: reduce)').matches;
let closeCurrent=null,canLeaveDialog=()=>true;
function modal(title,body,{wide=false,onSubmit}={}){closeCurrent?.(true);const dialogReturn=document.activeElement;const o=document.createElement('div');o.className='dz-overlay';o.innerHTML=`<section class="dz-dialog ${wide?'wide':''}" role="dialog" aria-modal="true" aria-labelledby="dz-title"><header class="dz-dialog-head"><h2 id="dz-title">${esc(title)}</h2><button aria-label="关闭">${icon('close')}</button></header>${onSubmit?`<form class="dz-form">${body}<p class="dz-error" role="alert"></p><div class="dz-actions">${btn('取消','modal-close') }<button class="dz-btn primary" type="submit">保存</button></div></form>`:`<div class="dz-dialog-body">${body}</div>`}</section>`;document.body.append(o);const box=$('.dz-dialog',o);let dirty=false,initial='';const form=$('form',o);if(form){initial=JSON.stringify([...new FormData(form)]);form.addEventListener('input',()=>dirty=true)}
 const canLeave=()=>!dirty||!form||JSON.stringify([...new FormData(form)])===initial||confirm('内容尚未保存，确定放弃吗？');
 canLeaveDialog=canLeave;
 const close=(force=false)=>{if(!force&&!canLeave())return;const finish=()=>{o.remove();if(closeCurrent===close){closeCurrent=null;canLeaveDialog=()=>true;dialogReturn?.focus?.()}};
 if(force||!window.gsap||reduced()){window.gsap?.killTweensOf([o,box]);finish();return}
 if(o.dataset.closing)return;
 o.dataset.closing='1';
 gsap.timeline({defaults:{duration:.17,ease:'power2.in',overwrite:true},onComplete:finish})
   .to(o,{autoAlpha:0}).to(box,{y:12,scale:.985},'<')};closeCurrent=close;$('header button',o).onclick=()=>close();o.addEventListener('click',e=>{if(e.target===o)close();if(e.target.closest('[data-action="modal-close"]'))close()});o.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();close()}if(e.key==='Tab'){const els=$$('button,input,textarea,select,a[href],[tabindex="0"]',o).filter(e=>!e.disabled&&e.offsetParent!==null);if(e.shiftKey&&document.activeElement===els[0]){e.preventDefault();els.at(-1)?.focus()}else if(!e.shiftKey&&document.activeElement===els.at(-1)){e.preventDefault();els[0]?.focus()}}});if(form)form.onsubmit=async e=>{e.preventDefault();let submit=$('[type=submit]',form);submit.disabled=true;try{const result=await onSubmit(Object.fromEntries(new FormData(form)),form);if(result!==false){dirty=false;close(true)}}catch(e){$('.dz-error',form).textContent=e.message||'保存失败，请重试'}finally{submit.disabled=false}};
 if(window.gsap&&!reduced())gsap.timeline({defaults:{duration:.23,ease:'power2.out'}}).from(o,{autoAlpha:0}).from(box,{y:18,scale:.985},'<');setTimeout(()=>($('input:not([type=hidden]),textarea,select',o)||$('header button',o)).focus(),50);return o}
const field=(label,name,value='',type='text',extra='')=>`<label>${label}<input name="${name}" type="${type}" value="${esc(value)}" ${extra}></label>`;
const select=(label,name,values,value)=>`<label>${label}<select name="${name}">${values.map(x=>`<option value="${esc(typeof x==='object'?x.id:x)}" ${value===(typeof x==='object'?x.id:x)?'selected':''}>${esc(typeof x==='object'?x.title:x)}</option>`).join('')}</select></label>`;
function go(key,query=''){const path=key==='dashboard'&&innerWidth<768?'/11-mobile-dashboard/':routes[key];if(!path)return;sessionStorage.setItem('dz-scroll-'+page,String($('main')?.scrollTop||scrollY));if(shell)shell.navigate(key,query);else location.href=path+query}
function taskForm(t=null,date=today()){return modal(t?'编辑学习任务':'新建学习任务',`${field('任务标题 *','title',t?.title||'','text','required maxlength="140"') }<div class="dz-form-grid">${select('学科','subject',state.subjects,t?.subject||state.subjects[0])}${select('优先级','priority',['高','中','低'],t?.priority||'中')}${field('安排日期','date',t?.date??date,'date')}${field('截止日期（可选）','deadline',t?.deadline||'','date')}${field('开始时间','start',t?.start||'','time')}${field('结束时间','end',t?.end||'','time')}</div>${select('关联目标','goal',[{id:'',title:'不关联'},...state.goals],t?.goal||'')}<label>说明<textarea name="note">${esc(t?.note||'')}</textarea></label><label>子任务（每行一项）<textarea name="subtaskText">${esc((t?.subtasks||[]).map(s=>s.title).join('\n'))}</textarea></label>`,{onSubmit:v=>{if(!v.title.trim())throw Error('请填写任务标题');if(v.start&&v.end&&v.end<=v.start)throw Error('结束时间必须晚于开始时间');const task={...t,...v,id:t?.id||uid(),title:v.title.trim(),done:t?.done||false,subtasks:v.subtaskText.split(/[\n/]/).map(s=>s.trim()).filter(Boolean).map(s=>({title:s,done:(t?.subtasks||[]).find(x=>x.title===s)?.done||false}))};if(t)state.tasks=state.tasks.map(x=>x.id===t.id?task:x);else state.tasks.unshift(task);if(!persist())return false;refresh();toast(t?'任务已更新':'任务已添加')}})}
function toggleTask(id){const t=state.tasks.find(x=>x.id===id);if(!t)return;if(!t.done&&t.subtasks.some(x=>!x.done)){modal('完成任务',`<p>还有未完成的子任务，选择本次处理方式。</p>${btn('仅完成主任务','finish-parent')} ${btn('同时完成全部子任务','finish-all','primary')}`).addEventListener('click',e=>{const a=e.target.closest('[data-action]')?.dataset.action;if(a?.startsWith('finish-')){t.done=true;if(a==='finish-all')t.subtasks.forEach(x=>x.done=true);persist();closeCurrent(true);refresh();toast('任务已完成')}});return}t.done=!t.done;if(persist()){refresh();toast(t.done?'任务已完成':'已恢复为待开始')}}
function taskDetail(id,back){const t=state.tasks.find(x=>x.id===id);if(!t)return;const o=modal(t.title,`<div class="dz-extra-top"><span class="dz-tag">${esc(t.subject)} · ${t.done?'已完成':t.priority+'优先级'}</span><span class="dz-muted">${esc(t.date||'待安排')} ${esc(t.start||'')}</span></div><p>${esc(t.note||'暂无任务说明')}</p><div>${t.subtasks.map((s,i)=>`<div class="dz-row"><button class="dz-check" role="checkbox" aria-checked="${s.done}" data-sub="${i}">✓</button><span>${esc(s.title)}</span></div>`).join('')}</div><div class="dz-actions">${btn('编辑 / 改期','edit-task')}${btn(t.done?'撤销完成':'标记已完成','complete-task','primary')}${btn('删除','delete-task','danger')}</div><p class="dz-muted">任务状态会同步到仪表盘和日历；章节进度单独计算。</p>`);if(back){const footer=$('.dz-actions',o);footer.insertAdjacentHTML('afterbegin',btn('返回任务列表','task-record-back'));attachAction($('[data-action=task-record-back]',o),back)}
 motion.completion();o.onclick=e=>{const sub=e.target.closest('[data-sub]');if(sub){const s=t.subtasks[+sub.dataset.sub];s.done=!s.done;const before=motion.completionSnapshot();if(persist())sub.setAttribute('aria-checked',s.done);refresh();motion.completion(before);return}const a=e.target.closest('[data-action]')?.dataset.action;if(a==='edit-task'){closeCurrent(true);taskForm(t)}if(a==='complete-task'){closeCurrent(true);toggleTask(t.id)}if(a==='delete-task')remove('tasks',id,()=>{closeCurrent(true);refresh()})}}
function remove(type,id,after=refresh){const list=state[type],i=list.findIndex(x=>x.id===id);if(i<0)return;if(!confirm('将此内容移至回收站？相关历史学习记录仍保留。'))return;const item=list.splice(i,1)[0];state.trash.push({id:uid(),type,item,deletedAt:Date.now()});if(persist()){after();toast('已移至回收站',false,()=>{list.splice(i,0,item);state.trash.pop();persist();refresh()})}}
function goalForm(g=null){modal(g?'编辑目标':'建立学习目标',`${field('目标名称 *','title',g?.title||'','text','required')}${select('学科','subject',state.subjects,g?.subject||state.subjects[0])}${field('计划截止日期','deadline',g?.deadline||'','date')}<label>章节 / 里程碑（每行一项）<textarea name="chapters">${esc((g?.chapters||[]).map(x=>x.title).join('\n'))}</textarea></label>`,{onSubmit:v=>{const chapters=v.chapters.split('\n').map(s=>s.trim()).filter(Boolean).map(title=>g?.chapters.find(x=>x.title===title)||{id:uid(),title,done:false,category:v.subject});const obj={id:g?.id||uid(),title:v.title,subject:v.subject,deadline:v.deadline,chapters};if(g)state.goals=state.goals.map(x=>x.id===g.id?obj:x);else state.goals.push(obj);if(!persist())return false;refresh();toast('目标已保存')}})}
function goalList(){const o=modal('我的学习目标',`${state.goals.map(g=>`<div class="dz-row"><div class="dz-row-text"><strong>${esc(g.title)}</strong><p>${g.chapters.filter(x=>x.done).length}/${g.chapters.length} 章节 · ${esc(g.deadline||'未设截止日期')}</p></div><button class="dz-btn small" data-goal="${g.id}">查看</button></div>`).join('')||empty('还没有学习目标')} ${btn('建立目标','new-goal','primary')}`);o.onclick=e=>{const id=e.target.closest('[data-goal]')?.dataset.goal;if(id){sessionStorage.setItem('dz-goal',id);go('goal')}if(e.target.closest('[data-action="new-goal"]'))goalForm()}}
function logsList(){const o=modal('学习记录与复盘',`${btn('补录学习记录','new-log','primary')}<p class="dz-muted">已记录 ${(state.logs.reduce((a,x)=>a+x.minutes,0)/60).toFixed(1)} 小时；记录时长与章节进度分别统计。</p>${state.logs.map(l=>`<div class="dz-row"><div class="dz-row-text"><strong>${esc(l.title)}</strong><p>${esc(l.date)} · ${l.minutes} 分钟 · ${esc(l.note)}</p></div><button class="dz-btn small" data-log="${l.id}">编辑</button><button class="dz-btn small" data-remove-log="${l.id}">删除</button></div>`).join('')||empty('还没有学习记录')}`,{wide:true});o.onclick=e=>{const id=e.target.closest('[data-log]')?.dataset.log;if(id){closeCurrent(true);logForm(state.logs.find(x=>x.id===id))}const del=e.target.closest('[data-remove-log]')?.dataset.removeLog;if(del)remove('logs',del,()=>{closeCurrent(true);logsList();refresh()});if(e.target.closest('[data-action="new-log"]')){closeCurrent(true);go('logs')}}}
function logForm(l=null){modal(l?'修改学习记录':'记录一次学习',`<div class="dz-form-grid">${field('日期','date',l?.date||today(),'date','required')}${field('学习时长（分钟）','minutes',l?.minutes||30,'number','min="1" max="1440" required')}</div>${field('学习内容 *','title',l?.title||'','text','required')}${select('关联目标','goal',[{id:'',title:'不关联'},...state.goals],l?.goal||'')}<label>复盘心得<textarea name="note">${esc(l?.note||'')}</textarea></label>`,{onSubmit:v=>{if(+v.minutes<=0||+v.minutes>1440)throw Error('时长需在 1–1440 分钟之间');let obj={...l,...v,id:l?.id||uid(),minutes:+v.minutes};if(l&&state.logs.some(x=>x.id===l.id))state.logs=state.logs.map(x=>x.id===l.id?obj:x);else state.logs.unshift(obj);if(!persist())return false;refresh();toast('学习记录已保存')}})}
let dbPromise;function db(){return dbPromise??=new Promise((res,rej)=>{const req=indexedDB.open(stateKey==='donezo-state-v1'?'donezo-files':stateKey+':files',1);req.onupgradeneeded=()=>req.result.createObjectStore('files');req.onsuccess=()=>res(req.result);req.onerror=()=>rej(Error('无法访问浏览器文件存储'))})}async function putFile(id,blob){const d=await db();return new Promise((res,rej)=>{const tx=d.transaction('files','readwrite');tx.objectStore('files').put(blob,id);tx.oncomplete=res;tx.onerror=()=>rej(Error('文件保存失败，可能存储空间不足'))})}async function getFile(id){const d=await db();return new Promise((res,rej)=>{let r=d.transaction('files').objectStore('files').get(id);r.onsuccess=()=>res(r.result);r.onerror=()=>rej(Error('文件读取失败'))})}
function upload(){const o=modal('添加学习资料',`<p class="dz-muted">文件保存在当前浏览器。支持 PDF、图片与其他文件；单个文件上限 20 MB。不会上传至云端。</p><label>选择文件（可多选）<input type="file" name="files" multiple></label>${field('或保存网页链接','url','','url')}${field('链接名称','name')}${select('学科','subject',state.subjects,state.subjects[0])}<div class="dz-upload-status" aria-live="polite"></div>`,{onSubmit:async(v,f)=>{const files=$('[name=files]',f).files,status=$('.dz-upload-status',f);if(!files.length&&!v.url)throw Error('请选择文件或填写网页链接');let count=0,errors=[];for(const file of files){if(file.size>20*1024*1024){errors.push(file.name+' 超过20MB');continue}if(state.materials.some(x=>x.name===file.name)&&!confirm(file.name+' 已存在，保留另一份吗？'))continue;const id=uid();status.textContent='正在保存 '+file.name;try{await putFile(id,file);state.materials.unshift({id,name:file.name,type:file.type.includes('pdf')?'PDF':file.type.startsWith('image/')?'图片':file.name.split('.').at(-1).toUpperCase(),subject:v.subject,size:file.size,mime:file.type,created:Date.now(),favorite:false,note:''});count++}catch(e){errors.push(file.name+'：'+e.message)}}if(v.url){const u=new URL(v.url);if(!['https:','http:'].includes(u.protocol))throw Error('仅支持 http/https 链接');state.materials.unshift({id:uid(),name:v.name||u.hostname,type:'链接',url:u.href,subject:v.subject,created:Date.now(),favorite:false,note:''});count++}if(!persist())return false;refresh();if(errors.length){status.textContent=`已保存 ${count} 项；失败：${errors.join('；')}。可以重新选择失败文件重试。`;$('[name=files]',f).value='';return false}toast('已保存 '+count+' 份资料')}});return o}
async function materialOpen(id){const m=state.materials.find(x=>x.id===id);if(!m)return;if(m.sample){go('detail','?id='+encodeURIComponent(id));return}const o=modal(m.name,`<div class="dz-preview">${empty('正在读取资料…')}</div><div class="dz-actions">${btn('编辑资料','edit-material')}${btn(m.favorite?'取消收藏':'收藏','favorite-material')}${btn('下载 / 打开','download-material','primary')}${btn('删除','delete-material','danger')}</div>`,{wide:true});let url;try{if(m.url){$('.dz-preview',o).innerHTML=`<p class="dz-muted">网页链接将在新标签页打开。</p><a class="dz-btn primary" target="_blank" rel="noopener noreferrer" href="${esc(m.url)}">打开 ${esc(m.name)}</a>`}else{const b=await getFile(id);if(!b)throw Error('此文件不在当前浏览器，请重新添加');url=URL.createObjectURL(b);$('.dz-preview',o).innerHTML=m.type==='PDF'?`<iframe title="PDF 预览" class="dz-file-preview" src="${url}"></iframe>`:m.type==='图片'?`<img alt="${esc(m.name)}" class="dz-resource-preview" src="${url}">`:`<p class="dz-muted">此文件类型无法内嵌预览，请下载后打开。</p>`}}catch(e){$('.dz-preview',o).innerHTML=empty(e.message)}o.onclick=e=>{let a=e.target.closest('[data-action]')?.dataset.action;if(a==='edit-material'){closeCurrent(true);materialEdit(m)}if(a==='favorite-material'){m.favorite=!m.favorite;persist();e.target.closest('button').textContent=m.favorite?'取消收藏':'收藏';refresh()}if(a==='delete-material')remove('materials',id,()=>{closeCurrent(true);refresh()});if(a==='download-material'){if(m.url)window.open(m.url,'_blank','noopener');else if(url){const a=document.createElement('a');a.href=url;a.download=m.name;downloadAnchor(a)}}};const observer=new MutationObserver(()=>{if(!o.isConnected){if(url)URL.revokeObjectURL(url);observer.disconnect()}});observer.observe(document.body,{childList:true})}
function materialEdit(m){modal('资料信息',`${field('资料名称','name',m.name,'text','required')}${select('学科','subject',state.subjects,m.subject)}${m.url?field('网页链接','url',m.url,'url'):''}<label>笔记<textarea name="note">${esc(m.note||'')}</textarea></label>`,{onSubmit:v=>{Object.assign(m,v);if(!persist())return false;refresh();toast('资料信息已保存')}})}
function recycle(){const o=modal('回收站',`${state.trash.map(t=>`<div class="dz-row"><strong>${esc(t.item.title||t.item.name)}</strong><button class="dz-btn small" data-restore="${t.id}">恢复</button><button class="dz-btn small danger" data-purge="${t.id}">永久删除</button></div>`).join('')||empty('回收站为空')}`);o.onclick=e=>{let b=e.target.closest('[data-restore],[data-purge]');if(!b)return;let id=b.dataset.restore||b.dataset.purge,t=state.trash.find(x=>x.id===id);if(!t)return;if(b.dataset.purge&&!confirm('永久删除后无法恢复，确定继续吗？'))return;if(b.dataset.restore)state[t.type].push(t.item);state.trash=state.trash.filter(x=>x.id!==id);persist();closeCurrent(true);recycle();refresh()}}
function downloadAnchor(a){const save=shell?.save||(window.DonezoNative&&window.parent===window?message=>window.DonezoNative.postMessage(message):null);if(save&&a.href.startsWith('blob:')){fetch(a.href).then(r=>r.blob()).then(blob=>{const reader=new FileReader();reader.onload=()=>save(JSON.stringify({action:'save',name:a.download||'donezo-file',mime:blob.type||'application/octet-stream',data:String(reader.result).split(',')[1]}));reader.readAsDataURL(blob)}).catch(()=>toast('导出失败，请重试',true));}else a.click()}
function exportData(){const blob=new Blob([JSON.stringify(state,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='donezo-learning-'+today()+'.json';downloadAnchor(a);setTimeout(()=>URL.revokeObjectURL(url),500);toast('学习档案已导出（不含上传文件本体）')}
async function photoData(file){if(!file)return null;if(file.size>8*1024*1024)throw Error('头像图片不能超过8MB');if(file.type&&!file.type.startsWith('image/'))throw Error('请选择图片文件');const url=URL.createObjectURL(file);try{const image=await new Promise((resolve,reject)=>{const im=new Image();im.onload=()=>resolve(im);im.onerror=()=>reject(Error('无法读取图片，请选择 JPG、PNG 或 WebP 图片'));im.src=url});const ratio=Math.min(1,512/Math.max(image.naturalWidth,image.naturalHeight));const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(image.naturalWidth*ratio));canvas.height=Math.max(1,Math.round(image.naturalHeight*ratio));const ctx=canvas.getContext('2d');ctx.fillStyle='#ffffff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(image,0,0,canvas.width,canvas.height);return canvas.toDataURL('image/jpeg',.88)}finally{URL.revokeObjectURL(url)}}
function hydrateAvatar(){const images=$$('header img,body>aside img,body>div>aside:first-child img,img[alt*="林墨"],main>section:first-child img.w-20');for(const img of images){if(!img.dataset.defaultAvatar)img.dataset.defaultAvatar=img.getAttribute('src');img.src=state.profile.avatar||img.dataset.defaultAvatar;img.alt=state.profile.name+'的头像';}if(page==='01-account'){const avatar=$('main>section:first-child img');if(avatar){const target=avatar.parentElement;target.title='点击从相册更换头像';target.setAttribute('aria-label','更换头像，从相册选择照片');attachAction(target,profileForm)}}}
function profileForm(){let pending=state.profile.avatar||'';const o=modal('编辑个人资料',`<label>头像 · 从相册选择<img class="dz-avatar-preview" alt="头像预览" src="${esc(pending||$('main>section:first-child img')?.getAttribute('src')||'/assets/689e36d204b6fcf9f656.jpg')}"><input type="file" name="avatar" accept="image/*"><span class="dz-muted">支持 JPG、PNG、WebP，最大 8MB；仅保存到当前设备。</span></label>${field('昵称','name',state.profile.name,'text','required')}${field('联系邮箱（个人展示）','email',state.profile.email,'email')}${field('个人简介','bio',state.profile.bio)}`,{onSubmit:async(v,f)=>{const file=$('[name=avatar]',f).files[0];const previous=state.profile;state.profile={...previous,name:v.name,email:v.email,bio:v.bio,avatar:file?await photoData(file):pending};if(!persist()){state.profile=previous;return false}refresh();hydrateAvatar();toast('个人资料与头像已保存')}});const input=$('input[type=file]',o);input.onchange=async()=>{const error=$('.dz-error',o);try{const data=await photoData(input.files[0]);if(data){pending=data;$('.dz-avatar-preview',o).src=data}error.textContent=''}catch(e){input.value='';error.textContent=e.message}}}
function search(query=''){const o=modal('搜索学习空间',`<input class="dz-search" placeholder="搜索任务、资料、目标、记录…" aria-label="搜索内容" value="${esc(query)}"><div class="dz-search-results"></div>`,{wide:true});const input=$('input',o),out=$('.dz-search-results',o);function run(){const q=input.value.trim().toLowerCase();if(!q){out.innerHTML=empty('输入名称或关键词，开始查找');return}let count=0;out.innerHTML=[['任务',state.tasks,'task'],['资料',state.materials,'mat'],['目标',state.goals,'goal'],['学习记录',state.logs,'log']].map(([name,list,type])=>{const found=list.filter(x=>(x.title||x.name||'').toLowerCase().includes(q));count+=found.length;return found.length?`<section class="dz-search-group"><h3>${name} · ${found.length}</h3>${found.map(x=>`<button class="dz-row" style="width:100%;text-align:left" data-result="${type}" data-id="${x.id}"><strong>${esc(x.title||x.name)}</strong>${icon('arrow_forward')}</button>`).join('')}</section>`:''}).join('');if(!count)out.innerHTML=empty('没有匹配结果，请更换关键词')}input.oninput=run;run();o.onclick=e=>{let b=e.target.closest('[data-result]');if(!b)return;closeCurrent(true);if(b.dataset.result==='task')taskDetail(b.dataset.id);if(b.dataset.result==='mat')materialOpen(b.dataset.id);if(b.dataset.result==='goal'){sessionStorage.setItem('dz-goal',b.dataset.id);go('goal')}if(b.dataset.result==='log')logForm(state.logs.find(x=>x.id===b.dataset.id))}}
let taskFilter='today',taskSubject='',materialSubject='',materialType='',materialSort=false,chapterFilter='',selectedTask=state.tasks[0]?.id,calDate=today(),calMonth=new Date(today()+'T12:00:00'),calWeek=false,calSubject='';
const color=s=>({'高等数学':'#2a75d3','大学英语':'#8e44ad','计算机408':'#009688','线性代数':'#c44536'}[s]||'#376853');
function taskRow(t){return `<div class="dz-list-card ${t.done?'dz-complete':''}" data-task="${t.id}" style="border:${t.id===selectedTask?'2px solid #144734':'1px solid transparent'};cursor:pointer"><button class="dz-check" role="checkbox" aria-label="${t.done?'撤销完成':'完成'} ${esc(t.title)}" aria-checked="${t.done}" data-toggle="${t.id}">✓</button><span style="width:8px;height:8px;background:${color(t.subject)};border-radius:50%;flex-shrink:0"></span><span class="dz-task-title" style="font-size:14px;font-weight:550;flex:1;min-width:0">${esc(t.title)}</span><span class="dz-tag">${t.done?'已完成':esc(t.start||t.date||'待安排')}</span></div>`}
function findExact(text,selector='button,a'){return $$(selector).find(e=>e.textContent.replace(/\s/g,'').includes(text.replace(/\s/g,'')))}
function getText(e){const c=e.cloneNode(true);$$('.material-symbols-outlined',c).forEach(x=>x.remove());return c.textContent.trim().replace(/\s+/g,' ')}
function attachAction(e,fn){if(!e)return;e.dataset.dzBound='1';e.onclick=ev=>{ev.preventDefault();fn(ev)};if(!['BUTTON','A','INPUT'].includes(e.tagName)){if(!e.hasAttribute('role'))e.setAttribute('role','button');e.tabIndex=0;e.onkeydown=ev=>{if(['Enter',' '].includes(ev.key)){ev.preventDefault();fn(ev)}}}}
function activatePill(button, animated=true){
 if(!button)return;
 const group=button.parentElement;
 for(const item of $$(':scope>button',group)){
   const selected=item===button;
   item.classList.toggle('dz-active-filter',selected);
   item.setAttribute('aria-pressed',String(selected));
 }
 if(group.classList.contains('dz-slider-pills'))motion.selection(group,button,animated);
}
function bindSlidingPills(labels,onSelect){
 const buttons=labels.map(label=>$$('main button').find(button=>getText(button)===label));
 if(!buttons[0])return;
 buttons[0].parentElement.classList.add('dz-slider-pills');
 activatePill(buttons[0],false);
 buttons.forEach((button,index)=>attachAction(button,()=>{
   activatePill(button);
   onSelect(labels[index],index);
 }));
}
function taskListRender(){const col=$('main .lg\\:col-span-7');if(!col)return;if(!col.dataset.prepared){col.dataset.prepared='1';const cards=$$(':scope>div',col).filter(e=>e.classList.contains('p-4'));cards.forEach(e=>e.remove());const list=document.createElement('div');list.id='dz-task-list';list.style='display:flex;flex-direction:column;gap:12px';col.insertBefore(list,col.children[1]||null)}let list=state.tasks.filter(t=>(!taskSubject||t.subject===taskSubject)&&(taskFilter==='all'||taskFilter==='completed'?taskFilter==='all'||t.done:taskFilter==='upcoming'?!!t.date&&t.date>today()&&!t.done:t.date===today()));if(materialSort)list.sort((a,b)=>(a.start||'99').localeCompare(b.start||'99'));$('#dz-task-list').innerHTML=list.map(taskRow).join('')||empty('此筛选下没有任务','new-task','添加任务');const h=findExact('今日待办','h2');if(h){h.textContent=taskFilter==='all'?'全部任务':taskFilter==='completed'?'已完成':taskFilter==='upcoming'?'即将到来':'今日待办';if(h.nextElementSibling)h.nextElementSibling.textContent=`(已完成 ${list.filter(t=>t.done).length}/${list.length})`}const labels=['今日到期','即将到来','全部任务','已完成'];labels.forEach((txt,i)=>{const b=findExact(txt);if(b){const spans=$$(':scope>span',b);if(spans.length>1)spans.at(-1).textContent=[state.tasks.filter(t=>t.date===today()).length,state.tasks.filter(t=>t.date>today()&&!t.done).length,state.tasks.length,state.tasks.filter(t=>t.done).length][i]}});taskPanelRender()}
function taskPanelRender(){const panel=$('main .lg\\:col-span-5');if(!panel)return;const t=state.tasks.find(x=>x.id===selectedTask)||state.tasks[0];if(!t){panel.innerHTML=empty('选择或创建一项任务','new-task','创建任务');return}selectedTask=t.id;if(!panel.dataset.original){panel.dataset.original=panel.innerHTML}if(!panel.querySelector('h1'))panel.innerHTML=panel.dataset.original;const title=$('h1',panel);if(title)title.textContent=t.title;const subt=findExact('子任务拆解清单','span');if(subt){const area=subt.parentElement?.parentElement;if(area){const list=$(':scope>.flex.flex-col.gap-2',area);if(list)list.innerHTML=t.subtasks.map((s,i)=>`<div class="dz-row" style="padding:10px;background:#f4f7f5;border-radius:12px"><button class="dz-check" role="checkbox" aria-checked="${s.done}" data-task-sub="${i}">✓</button><span style="font-size:13px;flex:1;${s.done?'text-decoration:line-through;color:#717973':''}">${esc(s.title)}</span></div>`).join('')||'<p class="dz-muted">暂无子任务，可在编辑时添加。</p>';subt.nextElementSibling&&(subt.nextElementSibling.textContent=`已完成 ${t.subtasks.filter(s=>s.done).length}/${t.subtasks.length}`)}}const complete=findExact('标记已完成')||findExact('撤销完成');if(complete){attachAction(complete,()=>toggleTask(t.id));const s=$('span:last-child',complete);if(s)s.textContent=t.done?'撤销完成':'标记已完成'}attachAction(findExact('改期'),()=>taskForm(t));attachAction($('button[title="更多操作"]',panel),()=>taskDetail(t.id));$$('[data-task-sub]',panel).forEach(b=>attachAction(b,()=>{t.subtasks[+b.dataset.taskSub].done=!t.subtasks[+b.dataset.taskSub].done;persist();refresh()}));const counter=$('strong',panel);if(counter)counter.textContent=t.deadline?`${t.deadline}${t.deadline<today()&&!t.done?' · 已逾期':''}`:t.date||'待安排'}
let matTemplate;function materialRender(){const grid=$('main>section.grid.xl\\:grid-cols-4');if(!grid)return;if(!matTemplate)matTemplate=grid.firstElementChild?.cloneNode(true);let list=state.materials.filter(m=>(!materialSubject||m.subject===materialSubject)&&(!materialType||m.type===materialType));list.sort((a,b)=>materialSort?a.name.localeCompare(b.name,'zh-CN'):(b.created||0)-(a.created||0));grid.replaceChildren();for(const m of list){let c=matTemplate.cloneNode(true);c.dataset.material=m.id;const h=$('h3',c);if(h)h.textContent=m.name;const type=$('.w-10.h-10',c);if(type)type.textContent=m.type;const info=h?.nextElementSibling;if(info)info.innerHTML=`<span>${m.sample?'示例资料':m.size?(m.size/1024/1024).toFixed(1)+' MB':'网页链接'}</span><span>·</span><span>${m.favorite?'已收藏':esc(m.subject)}</span>`;const foot=$('div.mt-6',c);if(foot){const label=$('span>span:last-child',foot);if(label)label.textContent=m.subject}const more=$$('button',c).find(b=>b.textContent.includes('more_horiz'));attachAction(more,()=>materialMenu(m));const open=$$('button',c).find(b=>b.textContent.includes('arrow_outward'));attachAction(open,()=>materialOpen(m.id));attachAction(h,()=>materialOpen(m.id));grid.append(c)}if(!list.length)grid.innerHTML=empty('没有匹配的学习资料','upload','添加资料');const nums=$$('main>section:first-child .text-metric-lg');if(nums.length>=4){nums[0].textContent=state.materials.length;nums[1].textContent=state.materials.filter(m=>m.type==='PDF').length;nums[2].textContent=state.materials.filter(m=>m.type==='笔记').length;nums[3].textContent=(state.materials.reduce((a,m)=>a+(m.size||0),0)/1024/1024).toFixed(1);nums[3].nextElementSibling.textContent='MB · 本机'}const pills=$$('main>section:nth-child(2) button').filter(b=>getText(b).includes('·'));pills.forEach((b,i)=>{let label=['全部','高等数学','大学英语','计算机408','线性代数'][i];if(label){b.innerHTML=(i?`<span style="width:6px;height:6px;border-radius:50%;background:${color(label)}"></span>`:'')+`${label} · ${i?state.materials.filter(m=>m.subject===label).length:state.materials.length}`}})}
function materialMenu(m){const o=modal(m.name,`${btn('打开资料','open-material','primary')}${btn('编辑名称、学科与笔记','edit-material')}${btn(m.favorite?'取消收藏':'收藏资料','favorite-material')}${btn('移至回收站','delete-material','danger')}`);o.onclick=e=>{const a=e.target.closest('[data-action]')?.dataset.action;if(a==='open-material'){closeCurrent(true);materialOpen(m.id)}if(a==='edit-material'){closeCurrent(true);materialEdit(m)}if(a==='favorite-material'){m.favorite=!m.favorite;persist();closeCurrent(true);refresh();toast(m.favorite?'已收藏':'已取消收藏')}if(a==='delete-material')remove('materials',m.id,()=>{closeCurrent(true);refresh()})}}
function selectedGoal(){return state.goals.find(x=>x.id===sessionStorage.getItem('dz-goal'))||state.goals[0]}
let chapterTemplate;function goalRender(){const g=selectedGoal();if(!g){$('main').innerHTML=empty('先建立一个目标，再拆分学习章节','new-goal','建立目标');return}const h=$('main h1');if(h)h.textContent='《'+g.title+'》';const ch=findExact('重点章节与考核点','h2');let list=ch?.parentElement?.parentElement?.nextElementSibling;if(list){if(!chapterTemplate)chapterTemplate=list.firstElementChild?.cloneNode(true);list.replaceChildren();for(const c of g.chapters.filter(x=>!chapterFilter||x.category===chapterFilter)){let el=chapterTemplate.cloneNode(true);el.dataset.chapter=c.id;const title=$('.truncate',el);if(title)title.textContent=c.title;const category=$('.text-discipline-math',el);if(category)category.textContent=c.category;const description=$('.text-body-sm',el);if(description)description.textContent='点击左侧切换完成状态 · 章节等权统计';const check=$('.w-6.h-6',el);if(check){check.innerHTML=icon(c.done?'check':'radio_button_unchecked');check.classList.toggle('dz-chapter-done',c.done);check.setAttribute('role','checkbox');check.setAttribute('aria-checked',c.done);check.tabIndex=0;const toggle=()=>{c.done=!c.done;persist();refresh()};check.onclick=toggle;check.onkeydown=e=>{if(e.key===' '){e.preventDefault();toggle()}}}const end=$(':scope>div:last-child',el);if(end)end.innerHTML=`<button class="dz-btn small" data-ch-edit="${c.id}" aria-label="编辑章节">${icon('edit')}</button><span class="dz-tag">${c.done?'已通关':'待开始'}</span>`;list.append(el)}if(!list.children.length)list.innerHTML=empty('此分类暂无章节','add-chapter','添加章节');const count=$('.rounded-full',ch.parentElement);if(count)count.textContent=g.chapters.length+' 节'}const n=g.chapters.filter(c=>c.done).length,total=g.chapters.length,pct=total?Math.round(n/total*100):0;const metrics=$$('main>section:nth-child(2) .text-metric-xl');if(metrics[0])metrics[0].textContent=total?pct:'—';if(metrics[1]){metrics[1].textContent=n;metrics[1].nextElementSibling.textContent=`/ ${total} 节`}if(metrics[2])metrics[2].textContent=(state.logs.filter(l=>l.goal===g.id).reduce((a,l)=>a+l.minutes,0)/60).toFixed(1);if(metrics[3])metrics[3].textContent=g.deadline?Math.max(0,Math.ceil((new Date(g.deadline)-new Date(today()))/864e5)):'—';$$('circle[stroke-dashoffset]',document).forEach(c=>c.setAttribute('stroke-dashoffset',119.4*(1-pct/100)));const bar=$('main>section:nth-child(2) [style*="width:"]');if(bar){bar.classList.add('dz-progress-fill');bar.style.width=pct+'%'}const actions=$('.dz-goal-actions')||document.createElement('div');if(!actions.isConnected){actions.className='dz-overview-actions dz-goal-actions';actions.innerHTML=btn('全部学习目标','goal-list')+btn('编辑目标','edit-goal')+btn('查看学习记录','logs-list');h?.parentElement.append(actions)}const subtitles=$$('main>section:nth-child(2) .text-label-sm');subtitles.forEach(e=>{if(e.textContent.includes('领先既定计划'))e.textContent='进度按完成章节数计算';if(e.textContent.includes('剩余'))e.textContent=`剩余 ${total-n} 章节`;if(e.textContent.includes('2025.12.27'))e.textContent=g.deadline||'未设日期'});$$('[data-ch-edit]').forEach(b=>attachAction(b,()=>chapterForm(g,g.chapters.find(c=>c.id===b.dataset.chEdit))))}
function chapterForm(g=selectedGoal(),c=null){if(!g){goalForm();return}modal(c?'编辑章节':'添加章节',`${field('章节名称','title',c?.title||'','text','required')}${select('分类','category',['数据结构','组成原理','操作系统','图论专题',g.subject],c?.category||g.subject)}${field('排序位置','position',c?g.chapters.indexOf(c)+1:g.chapters.length+1,'number','min="1"')}`,{onSubmit:v=>{const obj={id:c?.id||uid(),title:v.title,category:v.category,done:c?.done||false};g.chapters=g.chapters.filter(x=>x.id!==obj.id);g.chapters.splice(Math.max(0,+v.position-1),0,obj);if(!persist())return false;refresh();toast('章节已保存')}})}
function todayRender(){
 const date=today(),tasks=state.tasks.filter(t=>t.date===date),logs=state.logs.filter(l=>l.date===date);
 const completed=tasks.filter(t=>t.done).length,percentage=tasks.length?Math.round(completed/tasks.length*100):0;
 const minutes=logs.reduce((sum,log)=>sum+Number(log.minutes),0);
 const dateLabel=$('#daily-date');
 dateLabel.dataset.date=date;
 dateLabel.textContent=new Intl.DateTimeFormat('zh-CN',{month:'long',day:'numeric',weekday:'long',timeZone:'Asia/Shanghai'}).format(new Date());
 $('#daily-completed').textContent=completed;
 $('#daily-total').textContent='/ '+tasks.length+' 项';
 $('#daily-percentage').textContent=percentage+'%';
 $('#daily-arc').setAttribute('stroke-dashoffset',226.195*(1-percentage/100));
 $('#daily-status').textContent=!tasks.length?'从一项学习任务开始':completed===tasks.length?'今日任务已全部完成':'还有 '+(tasks.length-completed)+' 项待完成';
 $('#daily-pending [data-count]').textContent=tasks.length-completed;
 $('#daily-priority [data-count]').textContent=tasks.filter(t=>!t.done&&t.priority==='高').length;
 $('#daily-focus [data-count]').textContent=minutes<60?minutes:(minutes/60).toFixed(1);
 $('#daily-focus-unit').textContent=minutes<60?'分钟':'小时';
 const priority={'高':0,'中':1,'低':2};
 const sorted=[...tasks].sort((a,b)=>Number(a.done)-Number(b.done)||
   (priority[a.priority]??3)-(priority[b.priority]??3)||(a.start||'99').localeCompare(b.start||'99'));
 $('#daily-tasks').innerHTML=sorted.slice(0,5).map(t=>`<div class="daily-task dz-row ${t.done?'dz-complete':''}">
   <button type="button" class="dz-check" role="checkbox" aria-checked="${t.done}" aria-label="${esc((t.done?'撤销完成 ':'完成 ')+t.title)}" data-toggle="${esc(t.id)}">✓</button>
   <div class="daily-task-copy"><button type="button" class="dz-task-title" data-task="${esc(t.id)}">${esc(t.title)}</button><small>${esc(t.subject)}${t.priority==='高'?' · 高优先级':''}</small></div>
   <span class="daily-task-time">${esc(t.start||'未设时间')}</span></div>`).join('')||empty('今天还没有安排任务','new-task','添加今日任务');
 $('#daily-all-tasks').hidden=!tasks.length;
 $('#daily-all-tasks').textContent=tasks.length>5?'查看全部 '+tasks.length+' 项':'查看明细';
 const subjects=[...new Set(tasks.map(t=>t.subject||'未分类'))];
 $('#daily-subject-count').textContent=subjects.length?subjects.length+' 个学科':'';
 $('#daily-subjects').innerHTML=subjects.map((subject,i)=>{
   const group=tasks.filter(t=>(t.subject||'未分类')===subject);
   const done=group.filter(t=>t.done).length;
   return `<button type="button" class="daily-subject" data-daily-subject="${i}">
     <div><span>${esc(subject)}</span><small>${done} / ${group.length} 项完成</small></div>
     <div class="daily-subject-track"><div class="daily-subject-fill dz-progress-fill" style="width:${done/group.length*100}%"></div></div></button>`;
 }).join('')||'<p class="daily-muted">添加任务后显示学科分布</p>';
 const bind=(selector,action)=>attachAction($(selector),action);
 bind('#daily-summary',()=>taskRecords('今日全部任务',state.tasks.filter(t=>t.date===today())));
 bind('#daily-all-tasks',()=>taskRecords('今日全部任务',state.tasks.filter(t=>t.date===today())));
 bind('#daily-pending',()=>taskRecords('今日待完成任务',state.tasks.filter(t=>t.date===today()&&!t.done)));
 bind('#daily-priority',()=>taskRecords('今日高优先级任务',state.tasks.filter(t=>t.date===today()&&!t.done&&t.priority==='高')));
 bind('#daily-focus',()=>logRecords('今日专注记录',state.logs.filter(l=>l.date===today())));
 $$('[data-daily-subject]').forEach(button=>attachAction(button,()=>{
   const subject=subjects[Number(button.dataset.dailySubject)];
   taskRecords(subject+' · 今日任务',state.tasks.filter(t=>t.date===today()&&(t.subject||'未分类')===subject));
 }));
}

function dashboardRender(){const main=$('main');if(!main)return;let name=$('h1',main);if(name&&/早安/.test(name.textContent))name.textContent='早安，'+state.profile.name+(page==='04-dashboard'?'！':'');const nums=$$('.text-metric-xl,.text-metric-lg',main).filter(x=>/^\d+(\.\d+)?$/.test(x.textContent.trim()));if(page==='04-dashboard'){const a=$$('#dz-dashboard-metrics .text-metric-xl');const n=a.length?a:nums.slice(0,4);if(n[0])n[0].textContent=(state.logs.reduce((a,l)=>a+l.minutes,0)/60).toFixed(1);if(n[1])n[1].textContent=state.tasks.filter(t=>t.done).length;if(n[2])n[2].textContent=state.tasks.filter(t=>!t.done&&t.date).length;if(n[3])n[3].textContent=state.tasks.filter(t=>!t.done&&!t.date).length}let heading=findExact(page==='04-dashboard'?'任务清单':'今日核心待办','h2,h3');if(heading){let card=page==='11-mobile-dashboard'?heading.closest('section'):heading.closest('[class*="rounded-"]');if(card){let list=$('.dz-dash-tasks',card);if(!list){const original=heading.parentElement.nextElementSibling;if(original){list=original;list.classList.add('dz-dash-tasks')}else{list=document.createElement('div');list.className='dz-dash-tasks';heading.parentElement.after(list)}}const tasks=state.tasks.filter(t=>t.date===today()).slice(0,3);list.innerHTML=tasks.map(t=>`<div class="dz-row ${t.done?'dz-complete':''}"><button class="dz-check" role="checkbox" aria-checked="${t.done}" aria-label="切换 ${esc(t.title)} 完成状态" data-toggle="${t.id}">✓</button><button class="dz-task-title" style="flex:1;text-align:left;font-size:13px;font-weight:600" data-task="${t.id}">${esc(t.title)}</button><span class="dz-muted">${esc(t.start||'')}</span></div>`).join('')||empty('今天还没有学习安排','new-task','安排任务')}}const done=state.tasks.filter(t=>t.done).length;$$('main span').filter(x=>/^\d+\s*\/\s*\d+$/.test(x.textContent.trim())&&x.children.length===0).forEach(e=>e.textContent=done+' / '+state.tasks.length);const pct=selectedGoal()?.chapters.length?Math.round(selectedGoal().chapters.filter(c=>c.done).length/selectedGoal().chapters.length*100):0;$$('main span').filter(x=>x.textContent.trim()==='68%').forEach(x=>x.textContent=pct+'%');$$('main a').forEach(a=>{if(/全部任务/.test(a.textContent))attachAction(a,()=>go('tasks'))});if(page==='11-mobile-dashboard'){const host=$('main');if(!$('.dz-quick-mobile')){const actions=document.createElement('div');actions.className='dz-overview-actions dz-quick-mobile';actions.style='padding:0 20px 12px';actions.innerHTML=btn('+ 新任务','new-task','primary small')+btn('记一条','new-log','small');host.children[1]?.after(actions)}}}
function calendarRender(inRefresh=false,selectOnly=false){const grids=$$('main .grid.grid-cols-7'),grid=grids.find(g=>g.children.length>=28);if(!grid&&!$('#dz-cal-grid'))return;const target=$('#dz-cal-grid')||grid;target.id='dz-cal-grid';target.classList.add('dz-calendar-grid');target.classList.toggle('dz-week',calWeek);const before=target.dzCalendarState;
 const completion=inRefresh?null:motion.completionSnapshot();
 const y=calMonth.getFullYear(),m=calMonth.getMonth(),first=new Date(y,m,1),offset=(first.getDay()+6)%7,start=calWeek?new Date(calDate+'T12:00:00'):new Date(y,m,1-offset);if(calWeek)start.setDate(start.getDate()-((start.getDay()+6)%7));const count=calWeek?7:Math.ceil((offset+new Date(y,m+1,0).getDate())/7)*7;const after={period:calWeek?start.getTime():first.getTime(),date:calDate,filter:calSubject+'|'+calWeek,month:dateMonth(calMonth)};
 const samePeriod=before?.period===after.period && before.filter===after.filter;
 if(!(selectOnly && samePeriod && before.month===after.month)){
 target.replaceChildren();
 for(let i=0;i<count;i++){const d=new Date(start);d.setDate(d.getDate()+i);const date=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`,tasks=state.tasks.filter(t=>t.date===date&&(!calSubject||t.subject===calSubject)),cell=document.createElement('button');cell.className='dz-day h-24 md:h-28 p-2 rounded-xl bg-surface-canvas/60 border border-forest-dark/5 flex flex-col justify-between';cell.dataset.date=date;if(d.getMonth()!==m)cell.style.opacity='.4';cell.setAttribute('aria-label',date+' '+tasks.length+'项任务');cell.setAttribute('aria-pressed',String(date===calDate));cell.innerHTML=`<span class="dz-day-label">${d.getDate()}${date===today()?' · 今天':''}</span><div style="width:100%;text-align:left">${tasks.slice(0,2).map(t=>`<span class="dz-event" data-completion="${esc(t.id)}" data-done="${t.done}">${esc(t.title)}</span>`).join('')}${tasks.length>2?`<span class="dz-muted">+${tasks.length-2}</span>`:''}</div>`;cell.onclick=()=>{calDate=date;calMonth=new Date(date+'T12:00:00');calendarRender(false,true)};cell.ondblclick=()=>taskForm(null,date);target.append(cell)}
 }
 let selected;
 for(const cell of $$('.dz-day',target)){
   const active=cell.dataset.date===calDate;
   cell.setAttribute('aria-pressed',String(active));
   if(active)selected=cell;
 }
 motion.selection(target,selected,samePeriod && before.date!==after.date);
 const h=$('main h1');if(h)h.textContent=`${y}年${m+1}月`;const heading=findExact('当日时间轴清单','h2');if(heading){const panel=heading.closest('section')||heading.parentElement.parentElement;let events=$('#dz-day-events',panel);if(!events){events=document.createElement('div');events.id='dz-day-events';heading.parentElement.after(events);let next=events.nextElementSibling;while(next){const old=next;next=next.nextElementSibling;if(!old.querySelector('button')?.textContent.includes('添加日程'))old.remove()}}const list=state.tasks.filter(t=>t.date===calDate&&(!calSubject||t.subject===calSubject));events.innerHTML=`<p class="dz-muted" style="margin:8px 0">${calDate} · ${list.length} 项安排</p>`+(list.map(taskRow).join('')||empty('当天暂无日程','calendar-add','安排学习'));const add=findExact('添加日程');if(add){add.innerHTML=icon('add_circle')+'为'+calDate+'添加日程';attachAction(add,()=>taskForm(null,calDate))}}
 target.dzCalendarState=after;
 motion.calendar(before,after);
 if(completion)motion.completion(completion);
}
function groupForm(g=null){modal(g?'小组设置':'创建学习小组',`${field('小组名称','name',g?.name||'','text','required')}<label>小组说明<textarea name="description">${esc(g?.description||'')}</textarea></label><p class="dz-muted">本地演示：成员与共享内容保存在当前浏览器，尚未跨账号同步。</p>`,{onSubmit:v=>{if(g)Object.assign(g,v);else state.groups.push({id:uid(),...v,members:[state.profile.name],tasks:[]});if(!persist())return false;refresh();toast('小组已保存')}})}
let groupTemplate, groupFilter='全部';
function applyGroupFilter(){
 for(const checkbox of $$('main [data-group-toggle]')){
   const done=checkbox.getAttribute('aria-checked')==='true';
   checkbox.closest('.dz-group-row').hidden=groupFilter!=='全部' && done!==(groupFilter==='已交付');
 }
}
function groupRender(){const g=state.groups[0];if(!g){$('main').innerHTML=empty('还没有学习小组','new-group','创建小组');return}const h=$('main h1');if(h)h.textContent=g.name;const status=findExact('小组共享任务看板','h2');const board=status?.closest('section'),list=board?$('.divide-y',board):null;if(list){if(!groupTemplate)groupTemplate=list.firstElementChild?.cloneNode(true);list.replaceChildren();for(const t of g.tasks){const row=groupTemplate.cloneNode(true),label=$('.truncate',row);row.classList.add('dz-group-row');if(label){label.textContent=t.title;label.style.textDecoration=t.done?'line-through':'none'}const checkbox=$('.w-5.h-5',row);if(checkbox){checkbox.innerHTML=icon(t.done?'check':'radio_button_unchecked');checkbox.classList.toggle('dz-chapter-done',t.done);checkbox.dataset.groupToggle=t.id;checkbox.setAttribute('role','checkbox');checkbox.setAttribute('aria-checked',t.done);checkbox.tabIndex=0;attachAction(checkbox,()=>{t.done=!t.done;persist();refresh()})}const right=$(':scope>div:last-child',row);if(right)right.innerHTML=`<button class="dz-btn small" data-owner="${t.id}">${esc(t.owner||'认领任务')}</button><span class="dz-tag">${t.done?'已交付':'待推进'}</span>`;list.append(row)}if(!g.tasks.length)list.innerHTML=empty('还没有小组任务','group-task','添加任务');const badge=status.nextElementSibling;if(badge)badge.textContent='本地演示';$$('[data-owner]',list).forEach(b=>attachAction(b,()=>{const t=g.tasks.find(x=>x.id===b.dataset.owner);modal('分配任务',select('负责人','owner',g.members,t.owner),{onSubmit:v=>{t.owner=v.owner;persist();groupRender();toast('负责人已更新')}})}))}let extra=$('#dz-group-manager');if(!extra){extra=document.createElement('section');extra.id='dz-group-manager';extra.className='dz-extra';$('main').append(extra)}extra.innerHTML=`<div class="dz-extra-top"><h2>小组设置</h2><span class="dz-tag">组长 · 本地演示</span></div><p class="dz-muted">${esc(g.description)}</p><div class="dz-overview-actions">${btn('我的小组','groups-list','small')}${btn('编辑小组','edit-group','small')}${btn('管理成员','members','small')}${btn('邀请成员','invite-member','small primary')}</div>`;const nums=$$('#dz-group-metrics .text-metric-lg');if(nums[0])nums[0].textContent=g.tasks.length;if(nums[1])nums[1].textContent=g.tasks.filter(t=>t.done).length;if(nums[2])nums[2].textContent=g.tasks.filter(t=>!t.done).length;if(nums[3])nums[3].textContent=g.tasks.filter(t=>!t.owner).length;$$('main button').filter(b=>b.textContent.trim()==='north_east').forEach(b=>attachAction(b,()=>board?.scrollIntoView({behavior:'smooth'})));attachAction(findExact('进入'),members);applyGroupFilter()}
function members(){const g=state.groups[0];if(!g)return;const o=modal('小组成员',`<p class="dz-muted">${esc(g.name)} · ${g.members.length} 人 · 本地演示成员名单</p>${g.members.map((name,i)=>`<div class="dz-row"><strong>${esc(name)}</strong>${i===0?'<span class="dz-tag">组长</span>':`<button class="dz-btn small" data-remove-member="${i}">移除</button>`}</div>`).join('')} ${btn('添加演示成员','invite-member','primary')}`);o.onclick=e=>{const b=e.target.closest('[data-remove-member]');if(b&&confirm('移除此成员？')){g.members.splice(+b.dataset.removeMember,1);persist();closeCurrent(true);members();refresh()}if(e.target.closest('[data-action="invite-member"]'))inviteMember()}}
function inviteMember(){const g=state.groups[0];if(!g)return;modal('邀请成员 · 本地演示',`${field('成员昵称','name','','text','required')}<p class="dz-muted">添加到本机演示名单，不会向他人发送邀请。真实邀请链接需接入账号服务。</p>`,{onSubmit:v=>{if(g.members.includes(v.name))throw Error('此成员已在小组中');g.members.push(v.name);if(!persist())return false;refresh();toast('演示成员已添加')}})}
function groupTask(){const g=state.groups[0];if(!g){groupForm();return}modal('分配小组任务',`${field('任务标题','title','','text','required')}${select('负责人','owner',g.members,g.members[0])}`,{onSubmit:v=>{g.tasks.push({id:uid(),...v,done:false});if(!persist())return false;refresh();toast('小组任务已添加')}})}
function moreMenu(){const o=modal('学习空间',`${Object.entries({goal:'学习进度与目标',logs:'学习记录与复盘',group:'小组协作',settings:'设置与偏好',account:'账号与个人中心',imports:'导入'}).map(([k,t])=>`<button class="dz-row" data-route="${k}" style="width:100%;text-align:left"><strong>${t}</strong>${icon('arrow_forward')}</button>`).join('')}`);o.onclick=e=>{const b=e.target.closest('[data-route]');if(b)go(b.dataset.route)}}
function demoMenu(){const o=modal('当前学习空间',`<p class="dz-muted">这是浏览器本地保存的前端版本。${state.demo?'当前使用已标注的 Stitch 示例资料和学习任务。':'当前为空白个人空间。'}文件保存在本机，不会跨设备自动同步。</p>${btn('导出当前学习档案','export')}${btn('清空示例，开始自己的记录','clear-demo')}${btn('恢复 Stitch 示例数据','reset-demo')}<p class="dz-muted">清空前请导出备份；清空会移除当前浏览器中的记录和文件索引。</p>`);o.onclick=async e=>{const a=e.target.closest('[data-action]')?.dataset.action;if(a==='clear-demo'||a==='reset-demo'){if(!confirm('这会替换当前学习数据，确定继续吗？'))return;state=seed();if(a==='clear-demo'){state.demo=false;for(const k of ['tasks','goals','materials','logs','groups','trash'])state[k]=[];state.profile.name='我的学习空间'}if(persist())location.reload()}}}
function settingsTab(tab){if(tab==='学习偏好'){location.reload();return}const forms={'通用设置':()=>modal('通用设置',`${select('主题','theme',['light','dark'],state.settings.theme)}${select('每周起始日','weekStart',[{id:'1',title:'周一'},{id:'0',title:'周日'}],state.settings.weekStart)}<p class="dz-muted">当前统计与日程统一使用 Asia/Shanghai 时区。</p>`,{onSubmit:v=>{Object.assign(state.settings,v);if(!persist())return false;document.documentElement.classList.toggle('dz-dark',v.theme==='dark');toast('通用设置已保存')}}),'通知提醒':()=>modal('通知提醒',`<p class="dz-muted">当前仅提供站内通知，网页关闭后不会发送系统推送。</p><label style="flex-direction:row;align-items:center"><input type="checkbox" name="enabled" ${state.settings.notifications?'checked':''}> 启用站内截止提醒</label>`,{onSubmit:v=>{state.settings.notifications=v.enabled==='on';if(!persist())return false;toast('提醒偏好已保存')}}),'数据管理':()=>modal('数据管理',`${btn('导出学习档案 JSON','export')}${btn('安全回收站','recycle')}${btn('管理本地数据','demo-menu')}<p class="dz-muted">文件存放在当前浏览器。JSON 档案包含元数据，不包含附件文件本体。</p>`)};forms[tab]?.()}
function settingsInit(){const range=$('input[type=range]');if(range){range.value=state.settings.hours;range.oninput=()=>{const wrap=range.closest('section');if(wrap)$$('span',wrap).filter(e=>/^28$/.test(e.textContent.trim())).forEach(e=>e.textContent=range.value)}}let inputs=$$('input[type=checkbox]');inputs.forEach((e,i)=>e.checked=state.settings['toggle'+i]??e.checked);attachAction(findExact('保存更改'),()=>{state.settings.hours=+range?.value||28;inputs.forEach((e,i)=>state.settings['toggle'+i]=e.checked);persist();toast('学习偏好已保存')});attachAction(findExact('放弃'),()=>location.reload());$$('a').filter(a=>['通用设置','学习偏好','通知提醒','数据管理'].includes(getText(a))).forEach(a=>attachAction(a,()=>settingsTab(getText(a))));const subjectHead=findExact('核心学科管理','h3');if(subjectHead){const section=subjectHead.closest('section'),list=$('.divide-y',section);function renderSubjects(){if(!list)return;list.innerHTML=state.subjects.map((s,i)=>`<div class="dz-row"><span style="width:9px;height:9px;background:${color(s)};border-radius:50%"></span><strong style="flex:1">${esc(s)}</strong><button class="dz-btn small" data-subject-delete="${i}" aria-label="删除 ${esc(s)}">${icon('delete_outline')}</button></div>`).join('');$$('[data-subject-delete]',list).forEach(b=>attachAction(b,()=>{if(state.subjects.length===1){toast('至少保留一个分类');return}const s=state.subjects[+b.dataset.subjectDelete];if(!confirm('删除学科后，关联内容将转为“未分类”。'))return;state.subjects.splice(+b.dataset.subjectDelete,1);['tasks','materials','goals'].forEach(k=>state[k].forEach(x=>{if(x.subject===s)x.subject='未分类'}));persist();renderSubjects()}))}renderSubjects();attachAction(findExact('新增学科'),()=>modal('新增学科',field('学科名称','name','','text','required maxlength="30"'),{onSubmit:v=>{if(state.subjects.includes(v.name))throw Error('学科已存在');state.subjects.push(v.name);if(!persist())return false;renderSubjects();toast('学科已添加')}}))}}
function accountRender(){
 const heading=$('main h1');
 if(heading)heading.textContent=state.profile.name;
 $$('main p').filter(p=>p.textContent.includes('计算机科学')).forEach(p=>p.textContent=state.profile.bio);
 attachAction(findExact('编辑资料'),profileForm);
 const panel=$('#dz-cloud-account');
 if(!panel)return;
 const account=cloud?.session();
 panel.innerHTML=`<div class="dz-extra-top"><h2>云端账号</h2></div>
   <p class="dz-muted">${account?'已登录 '+esc(account.maskedEmail):'使用邮箱和邮件验证码登录。'}</p>
   <div class="dz-overview-actions">${account?btn('保存到云端','cloud-upload','primary')+
     btn('从云端恢复','cloud-download')+btn('导入本机记录','cloud-import')+btn('退出登录','cloud-logout'):
     btn('邮箱注册 / 登录','cloud-login','primary')}</div>
   <p class="dz-muted">云端保存学科、任务、目标和学习记录。资料附件、小组和头像保存在本机。</p>`;
}
function accountReload(){
 window.parent.location.assign('/?page=account');
}
function emailLogin(){
 if(!cloud){toast('请从应用首页进入个人中心',true);return}
 const emptyAccount=seed();
 emptyAccount.demo=false;
 emptyAccount.profile={name:'我的学习空间',email:'',bio:''};
 for(const key of ['tasks','goals','logs','materials','groups','trash'])emptyAccount[key]=[];
 const dialog=modal('邮箱注册 / 登录',
   field('邮箱地址','email','','email','required autocomplete="email" inputmode="email"')+
   `<label>邮件验证码<input name="code" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" autocomplete="one-time-code" required></label>
   <div class="dz-overview-actions">${btn('发送验证码','send-code')}</div>
   <p class="dz-muted" id="dz-email-status" role="status">首次验证成功时自动创建账号。</p>`,
   {onSubmit:async values=>{await cloud.login(values.email,values.code,emptyAccount);accountReload()}});
 const status=$('#dz-email-status',dialog), send=$('[data-action=send-code]',dialog);
 send.onclick=async()=>{
   const values=Object.fromEntries(new FormData($('form',dialog)));
   send.disabled=true;
   try{
     await cloud.sendCode(values.email);
     status.textContent='验证码已发送，请查收邮箱，5 分钟内有效。';
     setTimeout(()=>{send.disabled=false},60000);
   }catch(error){
     status.textContent=error.message;
     setTimeout(()=>{send.disabled=false},(error.retryAfter||0)*1000);
   }
 };
 $('button[type=submit]',dialog).textContent='验证并登录';
}
function cloudAction(action){
 const dialog=modal('云端学习数据',`<p class="dz-muted">${({
   upload:'把当前账号里的学习记录保存到云端。',
   download:'用云端版本替换当前账号的学科、任务、目标和学习记录。',
   import:'把本机未登录空间的学科、任务、目标和学习记录复制到当前账号。同 ID 的记录保留账号内版本。',
   logout:'退出后回到本机空间。这个账号的本机副本会保留，下次登录可继续使用。'
 })[action]}</p>`,{onSubmit:async()=>{
   if(cloud.stateKey()!==stateKey)throw Error('账号已切换，请重新打开应用');
   if(action==='upload')await cloud.upload(state);
   if(action==='download'){
     const snapshot=await cloud.download();
     if(cloud.stateKey()!==stateKey)throw Error('账号已切换，请重新打开应用');
     Object.assign(state,cloud.pickStudy(snapshot.data));
     if(!persist())return false;
     cloud.acceptRevision(snapshot.revision);
   }
   if(action==='import'){
     const local=cloud.guest();
     if(!local)throw Error('这台设备没有可导入的本机记录');
     state.subjects=[...new Set([...state.subjects,...local.subjects])];
     for(const key of ['tasks','goals','logs']){
       const known=new Set(state[key].map(item=>item.id));
       state[key].push(...local[key].filter(item=>!known.has(item.id)));
     }
     if(!persist())return false;
   }
   if(action==='logout'){await cloud.logout();accountReload();return}
   refresh();
   toast({upload:'已保存到云端',download:'已恢复云端记录',import:'已导入本机记录'}[action]);
 }});
 $('button[type=submit]',dialog).textContent={upload:'保存到云端',download:'确认恢复',import:'确认导入',logout:'退出登录'}[action];
}
function logsInit(){const ins=$$('input[type=text]');if(ins[0]){ins[0].removeAttribute('readonly');ins[0].type='date';ins[0].value=today()}if(ins[1]){ins[1].removeAttribute('readonly');ins[1].setAttribute('aria-label','学习时段，格式 HH:MM - HH:MM')}const content=$('div.min-h-\\[120px\\]');if(content){content.contentEditable='true';content.classList.add('dz-note-editor');content.setAttribute('role','textbox');content.setAttribute('aria-label','学习内容与复盘心得')}const selectGoal=$('select');if(selectGoal)selectGoal.innerHTML='<option value="">不关联目标</option>'+state.goals.map(g=>`<option value="${g.id}">${esc(g.title)}</option>`).join('');const save=findExact('确认存入学习历程');attachAction(save,()=>{let date=ins[0]?.value,time=ins[1]?.value||'',m=time.match(/^(\d{1,2}):(\d{2})\s*-\s*(\d{1,2}):(\d{2})$/);if(!date||!m){toast('请填写日期与有效时段，例如 14:00 - 16:30',true);return}let minutes=(+m[3]*60+ +m[4])-(+m[1]*60+ +m[2]);if(minutes<=0||minutes>1440||+m[1]>23||+m[3]>23||+m[2]>59||+m[4]>59){toast('结束时间需晚于开始时间，时段需在同一天内',true);return}const note=content?.innerText?.trim()||'';if(!note){toast('请填写学习内容',true);content?.focus();return}save.disabled=true;state.logs.unshift({id:uid(),date,minutes,title:note.split('\n')[0].slice(0,80),note,goal:selectGoal?.value||'',rating:$('input[name=focus_rating]:checked')?.value||'A'});if(persist()){toast('已存入学习历程');setTimeout(()=>go('goal'),450)}else save.disabled=false});const back=document.createElement('div');back.className='dz-logs-history';back.innerHTML=btn('← 返回','back','small')+' '+btn('学习历程','logs-list','small');document.body.append(back);attachAction(findExact('取消'),()=>go('goal'));const close=$$('button').find(b=>getText(b)===''&&b.textContent.includes('close'));attachAction(close,()=>go('goal'));$$('button').filter(b=>b.getAttribute('aria-label')==='移除资料').forEach(b=>attachAction(b,()=>b.parentElement.remove()));$$('button').filter(b=>/format_bold|format_italic|format_list_bulleted|check_box|code/.test(b.textContent)&&!b.textContent.includes('快速')).forEach(b=>attachAction(b,()=>{const kind=b.textContent.trim();content?.focus();document.execCommand(kind==='format_bold'?'bold':kind==='format_italic'?'italic':kind==='format_list_bulleted'?'insertUnorderedList':'insertText',false,kind==='code'?' `代码` ':kind==='check_box'?'☐ ':'')}))}
function detailInit(){let id=new URLSearchParams(location.search).get('id'),m=state.materials.find(x=>x.id===id)||state.materials[0];if(!m)return;const h=$('h1');if(h&&id)h.textContent=m.name+(m.type==='PDF'?'.pdf':'');const main=$('main'),note=$('textarea',main)||$$('[contenteditable]',main)[0];let x=document.createElement('section');x.className='dz-extra';x.innerHTML=`<div class="dz-extra-top"><h2>个人笔记</h2><span class="dz-tag">${m.sample?'原型预览示例':'本地资料'}</span></div><textarea class="dz-search" rows="5" aria-label="资料笔记">${esc(m.note||'')}</textarea><div class="dz-actions">${btn('编辑资料信息','edit-current-material')}${btn('保存笔记','save-note','primary')}</div>`;const side=$('main>aside');(side||main).append(x);attachAction($('[data-action=save-note]',x),()=>{m.note=$('textarea',x).value;if(persist())toast('笔记已保存')});attachAction($('[data-action=edit-current-material]',x),()=>materialEdit(m));let scale=1;const preview=findExact('§ 3.2','h2')?.parentElement;if(preview){preview.dataset.zoom='1';const setScale=n=>{scale=Math.max(.5,Math.min(2,n));preview.style.zoom=scale;toast('缩放 '+Math.round(scale*100)+'%')};$$('main button').forEach(b=>{const i=$('.material-symbols-outlined',b)?.textContent.trim();if(i==='remove')attachAction(b,()=>setScale(scale-.1));if(i==='add'&&getText(b)==='')attachAction(b,()=>setScale(scale+.1));if(i==='fit_screen')attachAction(b,()=>setScale(1));if(i==='fullscreen')attachAction(b,()=>preview.requestFullscreen?.());if(['chevron_left','chevron_right'].includes(i))attachAction(b,()=>toast('当前是原型示例讲义。添加真实 PDF 后可在资料库中预览。'))})}attachAction(findExact('展开全屏笔记'),()=>modal('资料笔记',`<label>笔记内容<textarea name="note">${esc(m.note||'')}</textarea></label>`,{onSubmit:v=>{m.note=v.note;persist();$('textarea',x).value=m.note;toast('笔记已保存')}}))}
function timerToggle(){const t=state.timer;if(t.running){t.elapsed+=Math.max(0,Date.now()-t.started);t.running=false}else{t.started=Date.now();t.running=true}persist();timerRender()}
function timerRender(){const t=state.timer,sec=Math.floor((t.elapsed+(t.running?Date.now()-t.started:0))/1000),v=[Math.floor(sec/3600),Math.floor(sec/60)%60,sec%60].map(n=>String(n).padStart(2,'0')).join(':');$$('main span,main div').filter(e=>e.children.length===0&&/^\d\d:\d\d:\d\d$/.test(e.textContent.trim())).forEach(e=>{if(!rendered)e.textContent='00:00:00';motion.timer(e,v)});$$('button').filter(b=>b.dataset.timer==='toggle').forEach(b=>{const i=$('.material-symbols-outlined',b);if(i)i.textContent=t.running?'pause':'play_arrow';b.setAttribute('aria-label',t.running?'暂停专注':'开始专注')})}
function timerModal(){modal('专注计时',`<p class="dz-muted">计时使用实际时间差，切换页面后仍能继续。停止后可保存一条学习记录。</p><div id="dz-timer-read" style="font-size:42px;font-weight:700;color:#144734;font-variant-numeric:tabular-nums">00:00:00</div>${btn(state.timer.running?'暂停':'开始','timer-toggle','primary')}${btn('结束并记录','timer-stop')}`);timerRender()}
function timerStop(){const t=state.timer;if(t.running){t.elapsed+=Date.now()-t.started;t.running=false}const minutes=Math.max(1,Math.round(t.elapsed/60000));t.elapsed=0;persist();timerRender();closeCurrent?.(true);logForm({id:uid(),date:today(),minutes,title:'专注学习',note:'',goal:selectedGoal()?.id||''})}
if(shell)document.addEventListener('click',e=>{
 const a=e.target.closest('a[href]');
 if(!a||e.defaultPrevented||e.ctrlKey||e.metaKey||e.shiftKey||a.target==='_blank')return;
 const url=new URL(a.href);
 if(url.origin!==location.origin)return;
 const key=url.pathname==='/11-mobile-dashboard/'?'dashboard':Object.keys(routes).find(key=>routes[key]===url.pathname);
 if(key){e.preventDefault();go(key,url.search)}
});
function animate(){if(!window.gsap||reduced())return;document.addEventListener('pointerdown',e=>{const b=e.target.closest('button.dz-btn,.dz-metric-interactive,.dz-record-row');if(b)gsap.timeline({defaults:{overwrite:'auto',ease:'power2.out'}}).to(b,{scale:.97,duration:.08}).to(b,{scale:1,duration:.17,clearProps:'transform'})});document.addEventListener('click',e=>{const a=e.target.closest('a[href]');if(!a||e.defaultPrevented||e.ctrlKey||e.metaKey||e.shiftKey||a.target==='_blank')return;const u=new URL(a.href);if(!shell&&u.origin===location.origin&&u.pathname!==location.pathname&&u.pathname.endsWith('/')){e.preventDefault();gsap.to($('main'),{autoAlpha:0,y:-5,duration:.13,ease:'power1.in',onComplete:()=>location.assign(a.href)})}});if(shell)return;const root=$('main')||document.body;const mm=gsap.matchMedia();mm.add('(prefers-reduced-motion: no-preference)',()=>{const ctx=gsap.context(()=>{const targets=$$(':scope>section,:scope>div',root).slice(0,7);gsap.timeline({defaults:{ease:'power2.out',duration:.28}}).from(targets,{autoAlpha:0,y:10,stagger:.035,clearProps:'all'});const bars=$$('[style*="width:"]',root).filter(e=>e.classList.contains('h-1.5')||e.classList.contains('h-1'));if(bars.length)gsap.from(bars,{scaleX:0,transformOrigin:'left',duration:.5,ease:'power2.out',clearProps:'transform'})},root);return()=>ctx.revert()});addEventListener('pagehide',()=>mm.revert(),{once:true})}
function navInit(){const mapping=[[/仪表盘/,'dashboard'],[/任务清单|^任务(?:\s|$)|全部任务/,'tasks'],[/资料库|^学习资料$|^资料$|全部资料/,'materials'],[/学习进度|里程碑进度/,'goal'],[/日历/,'calendar'],[/小组/,'group'],[/个人偏好|^设置$/,'settings'],[/账户设置|账户|账号/,'account'],[/快速复盘/,'logs']];$$('a[href="#"]').forEach(a=>{const s=getText(a);const match=mapping.find(([re])=>re.test(s));if(match){a.href=routes[match[1]];a.classList.add('dz-route');if(match[1]==='dashboard'&&innerWidth<768)a.href='/11-mobile-dashboard/'}else if(s==='更多')attachAction(a,moreMenu);else if(s==='退出')attachAction(a,()=>modal('退出学习空间',`<p class="dz-muted">当前是本地前端版本。离开页面不会删除已保存的资料。</p>${btn('返回个人中心','account')}`));else if(s==='帮助')attachAction(a,()=>modal('使用帮助',`<p class="dz-muted">从新建任务开始，把资料和目标关联起来。任务完成状态、日历安排与仪表盘会同步更新；记录学习时长后可查看复盘。数据保存在当前浏览器。</p>${btn('建立学习目标','new-goal','primary')}${btn('添加资料','upload')}`))});const sidebar=$('body>aside')||$('aside');if(sidebar){const nav=$('nav',sidebar);if(nav){if(!$$('a',nav).some(a=>getText(a).includes('学习进度'))){const a=$$('a',nav)[1]?.cloneNode(true);if(a){a.href=routes.goal;a.className='flex items-center gap-3 py-2.5 px-3 rounded-xl text-on-surface-variant hover:bg-surface-container transition-all';a.innerHTML=icon('insights')+'<span>学习进度</span>';nav.append(a)}}if(!$$('a',nav).some(a=>getText(a).includes('学习记录'))){const a=$$('a',nav)[1]?.cloneNode(true);if(a){a.href=routes.logs;a.className='flex items-center gap-3 py-2.5 px-3 rounded-xl text-on-surface-variant hover:bg-surface-container transition-all';a.innerHTML=icon('history_edu')+'<span>学习记录</span>';nav.append(a)}}}}$$('nav.fixed.bottom-0').forEach(n=>n.classList.add('dz-hidden'));const nav=document.createElement('nav');nav.className='dz-mobile-nav';nav.setAttribute('aria-label','主导航');nav.innerHTML=[['dashboard','space_dashboard','仪表盘'],['tasks','check_circle','任务'],['materials','menu_book','资料'],['calendar','calendar_today','日历'],['more','tune','更多']].map(([r,i,l])=>`<a href="${r==='more'?'#':r==='dashboard'?'/11-mobile-dashboard/':routes[r]}" ${r==='more'?'data-action="more"':''} class="${page.includes({dashboard:'dashboard',tasks:'tasks',materials:'materials',calendar:'calendar'}[r]||'___')?'active':''}">${icon(i)}<span>${l}</span></a>`).join('');document.body.append(nav);$$('header img').forEach(img=>attachAction(img,()=>go('account')));const badge=document.createElement('button');badge.className='dz-demo';badge.textContent=state.demo?'Stitch 示例 · 数据保存在本机':'个人空间 · 数据保存在本机';badge.dataset.action='demo-menu';document.body.append(badge)}
const importCategories=['学习','创作','其他'];

function renderImports(){
 const list=$('#import-list');
 if(!list)return;
 const entries=state.conversationImports||[];
 list.innerHTML=entries.map(entry=>`<button type="button" class="dz-row" data-import-id="${esc(entry.id)}"><strong>${esc(entry.title)}</strong><span class="dz-tag">${esc(entry.category)} · ${esc(entry.date)}</span></button>`).join('')||empty('还没有导入内容');
}

function importConversation(){
 const dialog=modal('导入对话',field('标题','title','','text','maxlength="120" placeholder="留空则使用正文第一行"')+
   select('分类','category',importCategories,'学习')+
   '<label>正文<textarea name="content" rows="8" required placeholder="粘贴 ChatGPT 整理好的总结或对话"></textarea></label>',{
   wide:true,
   onSubmit:values=>{
     const content=values.content.trim();
     if(!content)throw Error('请粘贴要导入的内容');
     const title=values.title.trim()||content.split('\n',1)[0].trim().slice(0,120);
     const existing=state.conversationImports;
     state.conversationImports=[{id:uid(),title,category:values.category,content,date:today()},...(existing||[])];
     if(!persist()){
       state.conversationImports=existing;
       throw Error('本机存储空间不足，内容未导入');
     }
     renderImports();
     toast('已导入对话');
   }
 });
 $('button[type=submit]',dialog).textContent='导入';
}

const actions={ 'import-conversation':importConversation,'cloud-login':emailLogin,'cloud-upload':()=>cloudAction('upload'),
'cloud-download':()=>cloudAction('download'),'cloud-import':()=>cloudAction('import'),'cloud-logout':()=>cloudAction('logout'),
'new-task':()=>taskForm(),'new-goal':()=>goalForm(),'goal-list':goalList,'edit-goal':()=>goalForm(selectedGoal()),'add-chapter':()=>chapterForm(),'logs-list':logsList,'new-log':()=>go('logs'),upload,'calendar-add':()=>taskForm(null,calDate),'new-group':()=>groupForm(),'edit-group':()=>groupForm(state.groups[0]),'invite-member':inviteMember,members,'group-task':groupTask,'demo-menu':demoMenu,more:moreMenu,export:exportData,recycle,'edit-profile':profileForm,account:()=>go('account'),back:()=>go('goal'),'timer-toggle':timerToggle,'timer-stop':timerStop,'groups-list':()=>{const o=modal('我的学习小组',`${state.groups.map(g=>`<div class="dz-row"><strong>${esc(g.name)}</strong><span class="dz-tag">${g.members.length}人</span></div>`).join('')}${btn('创建小组','new-group','primary')}`)}};
document.addEventListener('click',e=>{const el=e.target.closest('[data-action]');if(el&&!el.dataset.dzBound&&actions[el.dataset.action]){e.preventDefault();actions[el.dataset.action]()}const toggle=e.target.closest('[data-toggle]');if(toggle){e.preventDefault();toggleTask(toggle.dataset.toggle);return}const row=e.target.closest('[data-task]');if(row&&!e.target.closest('[data-toggle]')){if(page==='10-tasks'){selectedTask=row.dataset.task;taskListRender();motion.completion();if(innerWidth<768)taskDetail(selectedTask)}else taskDetail(row.dataset.task)}});
function generalBindings(){const named=[[/新建学习任务|新建项目/,()=>taskForm()],[/快速打卡|记一条|快速复盘/,()=>go('logs')],[/添加章节/,()=>chapterForm()],[/查看全部考点/,goalList],[/全部资料/,()=>go('materials')],[/进入研讨|进入研讨室/,()=>go('group')],[/邀请成员/,inviteMember],[/分配任务|添加新任务项/,groupTask],[/共享资料/,()=>modal('共享资料 · 本地演示',`<p class="dz-muted">个人资料默认私有。勾选资料将其标记为本地小组共享，不会上传到服务器。</p>${state.materials.map(m=>`<label class="dz-row" style="flex-direction:row"><span>${esc(m.name)}</span><input type="checkbox" name="${m.id}" ${m.shared?'checked':''}></label>`).join('')}`,{onSubmit:v=>{state.materials.forEach(m=>m.shared=!!v[m.id]);persist();toast('本地共享范围已保存')}})],[/展开全屏笔记/,()=>{}],[/下载手机客户端/,()=>go('dashboard')],[/导入数据/,()=>modal('导入学习档案',`<p class="dz-muted">仅导入由本系统导出的 JSON 元数据；导入会替换当前学习数据，上传文件本体不包含在档案中。</p><label>学习档案 JSON<input type="file" name="file" accept="application/json,.json" required></label>`,{onSubmit:async(v,f)=>{const file=$('[name=file]',f).files[0];if(!file)throw Error('请选择文件');const d=JSON.parse(await file.text());if(d.version!==1||!['tasks','goals','logs','materials','groups','subjects','trash'].every(k=>Array.isArray(d[k]))||!d.settings||!d.profile||!d.timer)throw Error('文件不是有效的学习档案');if(!confirm('确认替换当前学习数据？'))return false;state=d;if(persist())location.reload();return false}})],[/导出学习档案|申请导出/,exportData],[/安全回收站/,recycle],[/添加资料/,upload]];
 $$('button,a').forEach(b=>{if(b.dataset.dzBound||b.dataset.action)return;const s=getText(b),i=$('.material-symbols-outlined',b)?.textContent.trim();if(s==='快速打卡')b.classList.add('dz-header-short');const rule=named.find(([re])=>re.test(s));if(rule){attachAction(b,rule[1]);return}if(i==='menu'){attachAction(b,moreMenu);return}if(i==='notifications'||i==='mail'){attachAction(b,()=>modal('站内提醒',state.tasks.filter(t=>!t.done&&t.date&&t.date<=today()).map(t=>`<button class="dz-row" data-task="${t.id}"><strong>${esc(t.title)}</strong><span class="dz-tag">${t.date<today()?'安排日期已过':'今日安排'}</span></button>`).join('')||empty('暂时没有提醒')));return}if(i==='timer'){attachAction(b,timerModal);return}if(['pause','play_arrow'].includes(i)){b.dataset.timer='toggle';attachAction(b,timerToggle);return}if(i==='stop'){attachAction(b,timerStop);return}if(i==='replay'){attachAction(b,()=>{if(!confirm('重置当前计时？未记录的时长将清零。'))return;state.timer={running:false,elapsed:0,started:0};persist();timerRender()});return}if(i==='ios_share'){attachAction(b,()=>navigator.share?navigator.share({title:'Excel 学习空间',url:location.origin}).catch(()=>{}):toast('请复制浏览器地址分享页面'));return}});
 $$('header input[type=text]').forEach(input=>{input.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();search(input.value)}});input.setAttribute('aria-label',input.placeholder)});document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&['k','f'].includes(e.key.toLowerCase())){e.preventDefault();search()}});if(page==='11-mobile-dashboard')attachAction($$('header button').find(b=>b.textContent.includes('search')),()=>search())}
function pageBindings(){
 if(page==='conversation-import')$('#import-list').addEventListener('click',event=>{
   const row=event.target.closest('[data-import-id]');
   const entry=row&&state.conversationImports?.find(item=>item.id===row.dataset.importId);
   if(entry)modal(entry.title,`<p class="dz-muted">${esc(entry.category)} · ${esc(entry.date)}</p><div class="dz-import-content">${esc(entry.content)}</div>`,{wide:true});
 });
 if(page==='10-tasks'){const quick=$('input[placeholder^="输入新任务"]'),add=findExact('添加');const submit=()=>{if(!quick?.value.trim()){taskForm();return}state.tasks.unshift({id:uid(),title:quick.value.trim(),subject:state.subjects[0],date:today(),start:'',end:'',priority:'中',done:false,note:'',subtasks:[]});if(persist()){quick.value='';refresh();toast('任务已添加')}};if(quick)quick.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();submit()}};attachAction(add,submit);['今日到期','即将到来','全部任务','已完成'].forEach((t,i)=>{const b=findExact(t);attachAction(b,()=>{taskFilter=['today','upcoming','all','completed'][i];activatePill(b);taskListRender();motion.completion()})});['计网','高数','六级'].forEach((t,i)=>{const b=$$('main button').find(b=>getText(b)===t);attachAction(b,()=>{const sub=['计算机408','高等数学','大学英语'][i];taskSubject=taskSubject===sub?'':sub;activatePill(b);taskListRender();motion.completion()})});attachAction(findExact('按时间排序'),()=>{materialSort=!materialSort;taskListRender();motion.completion()})}
 if(page==='06-materials'){const pills=$$('main>section:nth-child(2) button').filter(b=>getText(b).includes('·'));pills.forEach((b,i)=>attachAction(b,()=>{materialSubject=['','高等数学','大学英语','计算机408','线性代数'][i];activatePill(b);materialRender()}));const toolbar=$('main>section:nth-child(2)');let uploadBtn=document.createElement('button');uploadBtn.className='dz-btn primary small';uploadBtn.innerHTML=icon('upload')+'添加资料';attachAction(uploadBtn,upload);toolbar.append(uploadBtn);attachAction(findExact('格式:'),()=>modal('筛选文件类型',select('资料格式','type',['全部','PDF','图片','笔记','XLSX','链接'],materialType||'全部'),{onSubmit:v=>{materialType=v.type==='全部'?'':v.type;materialRender()}}));attachAction(findExact('更新时间'),()=>{materialSort=!materialSort;materialRender();toast(materialSort?'按名称排序':'按更新时间排序')});attachAction($$('main button').find(b=>b.textContent.trim()==='grid_view'),()=>{$('main>section.grid.xl\\:grid-cols-4')?.classList.toggle('dz-material-list')});$$('main button').filter(b=>/^\d+$/.test(getText(b))||['chevron_left','chevron_right'].includes(b.textContent.trim())).forEach(b=>attachAction(b,()=>toast('当前已展示全部匹配资料')))}
 if(page==='02-goal-detail'){
   bindSlidingPills(['全部','数据结构','组成原理','操作系统'],label=>{
     chapterFilter=label==='全部'?'':label;
     refresh();
   });
 }
 if(page==='09-calendar'){const h=$('main h1'),wrap=h?.parentElement?.parentElement;$$('button',wrap||document).filter(b=>['chevron_left','chevron_right'].includes(b.textContent.trim())).forEach(b=>attachAction(b,()=>{const direction=b.textContent.includes('left')?-1:1;
 if(calWeek){calDate=dayPlus(calDate,direction*7);calMonth=new Date(calDate+'T12:00:00')}
 else{calMonth=new Date(calMonth.getFullYear(),calMonth.getMonth()+direction,1,12);calDate=dayPlus(today(),0);if(calDate.slice(0,7)!==dateMonth(calMonth))calDate=dateMonth(calMonth)+'-01'}
 calendarRender()}));attachAction(findExact('今天'),()=>{calDate=today();calMonth=new Date(today()+'T12:00:00');calendarRender()});bindSlidingPills(['月份视图','周视图'],(_,index)=>{calWeek=Boolean(index);calendarRender()});
 bindSlidingPills(['全部科目','高数','雅思','计网'],(_,index)=>{
   calSubject=['','高等数学','大学英语','计算机408'][index];
   calendarRender();
 });attachAction(findExact('修改所选日期'),()=>{const tasks=state.tasks.filter(t=>t.date===calDate);if(tasks[0])taskForm(tasks[0]);else taskForm(null,calDate)});attachAction(findExact('推迟至明天'),()=>{const list=state.tasks.filter(t=>t.date===calDate&&!t.done);if(!list.length){toast('当天没有可推迟的任务');return}if(!confirm('将当天 '+list.length+' 项未完成任务改至次日？'))return;list.forEach(t=>t.date=dayPlus(calDate,1));persist();calendarRender();toast('已调整安排日期，截止日期保持原值')})}
 if(page==='03-settings')settingsInit();if(page==='01-account')accountRender();if(page==='05-study-logs')logsInit();if(page==='08-material-detail')detailInit();if(page==='07-study-group'){
   bindSlidingPills(['全部','待推进','已交付'],label=>{
     groupFilter=label;
     applyGroupFilter();
   });
 }
}
function reconcile(){
const recent=state.logs.filter(l=>l.date>=dayPlus(today(),-6)&&l.date<=today());
const hours=recent.reduce((a,l)=>a+Number(l.minutes),0)/60,done=state.tasks.filter(t=>t.done).length,g=selectedGoal(),pct=g?.chapters.length?Math.round(g.chapters.filter(c=>c.done).length/g.chapters.length*100):0;
$$('aside a').forEach(a=>{if(getText(a).match(/^任务\s/)){const badge=$('.rounded-full',a);if(badge)badge.textContent=state.tasks.filter(t=>!t.done).length}});
if(page==='04-dashboard'){
const list=$('.dz-dash-tasks');if(list){list.style='display:flex;flex-direction:column;gap:8px';$$('.dz-row',list).forEach(row=>row.style.cssText='display:flex;gap:10px;align-items:center;border:1px solid #e5eae6;border-radius:12px;padding:10px');}
const dateSpan=$$('main span').find(e=>e.children.length===0&&/10月24日/.test(e.textContent));if(dateSpan)dateSpan.textContent=new Intl.DateTimeFormat('zh-CN',{month:'long',day:'numeric',weekday:'short',timeZone:'Asia/Shanghai'}).format(new Date());
const goalHeading=findExact('目标进度','h3');if(goalHeading){const card=goalHeading.closest('[class*="rounded-"]');const rate=$('.text-metric-lg',card);if(rate)rate.textContent=pct+'%';const foot=$(':scope>div:last-child',card);if(foot)foot.innerHTML=`<span>已完成 ${pct}%</span><span>待开始 ${100-pct}%</span>`;const paths=$$('svg path',card);if(paths[1]){paths[1].setAttribute('d','M 20 100 A 80 80 0 0 1 180 100');paths[1].setAttribute('stroke-dasharray','251.3');paths[1].setAttribute('stroke-dashoffset',251.3*(1-pct/100))}const sub=goalHeading.nextElementSibling;if(sub)sub.textContent=g?.subject||'尚无目标';attachAction(card,()=>go('goal'))}
const trend=findExact('专注趋势','h3');if(trend){const card=trend.closest('[class*="rounded-"]');const summary=$(':scope>div:last-child',card);if(summary)summary.innerHTML=`<span>近七天累计 ${hours.toFixed(1)}h</span><span style="color:#006d3e">记录 ${recent.length} 次</span>`;const avg=trend.nextElementSibling;if(avg)avg.textContent=(hours/7).toFixed(1)+'h / 日';}
$$('header p,header span').filter(e=>e.children.length===0&&e.textContent.trim()==='Totok Michael').forEach(e=>e.textContent=state.profile.name);$$('header p,header span').filter(e=>e.children.length===0&&e.textContent.trim()==='tmichael20@mail.com').forEach(e=>e.textContent=state.profile.email);
}
if(page==='11-mobile-dashboard'){
const a=$$('section[aria-label="核心指标"] article');if(a[0]){const n=$('.text-metric-lg',a[0]);if(n)n.textContent=hours.toFixed(1);const footer=a[0].lastElementChild;footer.textContent=recent.length+' 条学习记录'}if(a[1]){const n=$('.text-metric-lg',a[1]);if(n){n.textContent=done;n.nextElementSibling.textContent='/ '+state.tasks.length+'项'}const rate=state.tasks.length?Math.round(done/state.tasks.length*100):0;const bar=$('[class*="w-[90%]"]',a[1]);if(bar){bar.classList.add('dz-progress-fill');bar.style.width=rate+'%'}$$('span',a[1]).filter(e=>/^\d+%$/.test(e.textContent)).forEach(e=>{e.classList.add('dz-progress-number');e.textContent=rate+'%'})}
if(a[2])$('.text-metric-lg',a[2]).textContent=state.tasks.filter(t=>!t.done&&t.date).length;
if(a[3])$('.text-metric-lg',a[3]).textContent=state.tasks.filter(t=>!t.done&&!t.date).length;
const headerDate=$$('header p,header span').find(e=>/11月12日/.test(e.textContent));if(headerDate)headerDate.textContent=new Intl.DateTimeFormat('zh-CN',{month:'long',day:'numeric',weekday:'short'}).format(new Date());const h=findExact('今日核心待办','h2');if(h?.nextElementSibling)h.nextElementSibling.textContent=state.tasks.filter(t=>t.date===today()).length+' 项任务';
const section=$('section[aria-label="最近研读资料"]'),cards=$('.grid',section);if(cards){cards.innerHTML=state.materials.slice(0,2).map(m=>`<button class="bg-surface-card rounded-[20px] p-4 border border-forest-dark/[0.06] shadow-sm" data-open-material="${m.id}" style="text-align:left">${icon(m.type==='PDF'?'picture_as_pdf':'menu_book')}<strong style="display:block;font-size:14px;margin-top:12px">${esc(m.name)}</strong><span class="dz-muted">${esc(m.subject)}</span></button>`).join('')||empty('还没有资料','upload','添加资料');$$('[data-open-material]',cards).forEach(b=>attachAction(b,()=>materialOpen(b.dataset.openMaterial)))}attachAction(findExact('打卡'),()=>go('logs'));
}
if(page==='02-goal-detail'){
const metrics=$$('main>section:nth-child(2)>div');if(metrics[1]){$$('span',metrics[1]).filter(e=>e.children.length===0&&e.textContent.includes('剩余')).forEach(e=>e.textContent=`剩余 ${(g?.chapters.length||0)-(g?.chapters.filter(c=>c.done).length||0)} 章节`)}if(metrics[2]){$$('span',metrics[2]).filter(e=>e.children.length===0&&e.textContent.includes('本周新增')).forEach(e=>e.textContent='来源：有效学习记录');$$('span',metrics[2]).filter(e=>e.children.length===0&&e.textContent.includes('日均')).forEach(e=>e.textContent=state.logs.filter(l=>l.goal===g?.id).length+' 次记录')}if(metrics[3]){$$('span',metrics[3]).filter(e=>e.classList.contains('font-mono')&&e.children.length===0).forEach(e=>e.textContent=g?.deadline||'未设截止日期')}
const head=findExact('最近攻坚流水','h3');if(head){const block=head.closest('[class*="card-clean"]')||head.closest('[class*="rounded-"]');if(block){let list=$('.dz-goal-log-list',block);if(!list){list=document.createElement('div');list.className='dz-goal-log-list';head.parentElement.after(list);let next=list.nextElementSibling;while(next){let old=next;next=next.nextElementSibling;old.remove()}}list.innerHTML=state.logs.filter(l=>l.goal===g?.id).map(l=>`<button class="dz-row" data-edit-log="${l.id}" style="width:100%;text-align:left"><span class="dz-row-text"><strong>${esc(l.title)}</strong><p>${esc(l.date)} · ${l.minutes} 分钟</p></span>${icon('edit_note')}</button>`).join('')||empty('还没有与此目标关联的记录','new-log','记一条');$$('[data-edit-log]',list).forEach(b=>attachAction(b,()=>logForm(state.logs.find(l=>l.id===b.dataset.editLog))))}}
}
if(page==='09-calendar'){
const header=$$('main h2,h3').find(e=>/\d+月\d+日/.test(e.textContent));if(header)header.textContent=new Intl.DateTimeFormat('zh-CN',{month:'long',day:'numeric',weekday:'long'}).format(new Date(calDate+'T12:00:00'));const list=$('#dz-day-events');if(list&&!$('[data-action=calendar-add]',list)){const b=document.createElement('button');b.className='dz-btn small primary';b.style.marginTop='14px';b.textContent='+ 添加当日任务';b.dataset.action='calendar-add';list.append(b)}
}
if(page==='06-materials'){const footer=$$('main p,main span,main div').find(e=>e.children.length===0&&/显示\s*1\s*-\s*4/.test(e.textContent));if(footer)footer.textContent=`显示 ${state.materials.length?1:0} - ${state.materials.length} 共 ${state.materials.length} 项`;const space=$$('main span').find(e=>e.children.length===0&&e.textContent.trim()==='云存储空间');if(space)space.textContent='本地文件空间';}
if(page==='04-dashboard'){
const chart=$('main .h-44');if(chart){const bars=$$(':scope>div',chart),daily=Array.from({length:7},(_,i)=>state.logs.filter(l=>l.date===dayPlus(today(),i-6)).reduce((a,l)=>a+l.minutes,0)/60),max=Math.max(1,...daily);bars.forEach((col,i)=>{const bar=$(':scope>div',col),label=$(':scope>span',col);if(bar)bar.style.height=Math.max(2,daily[i]/max*136)+'px';if(label)label.textContent=['日','一','二','三','四','五','六'][new Date(dayPlus(today(),i-6)+'T12:00:00').getDay()];col.title=dayPlus(today(),i-6)+' · '+daily[i].toFixed(1)+'h'})}}
if(page==='02-goal-detail'){
const head=findExact('近 4 周有效工时','h3'),card=head?.closest('.card-clean');if(card){const logs=state.logs.filter(l=>l.goal===g?.id),weeks=Array.from({length:4},(_,i)=>logs.filter(l=>l.date>=dayPlus(today(),-27+i*7)&&l.date<=dayPlus(today(),-21+i*7)).reduce((a,l)=>a+l.minutes,0)/60),sum=weeks.reduce((a,b)=>a+b,0),max=Math.max(1,...weeks);if(head.nextElementSibling)head.nextElementSibling.textContent='按最近 28 天的学习记录统计';if(head.parentElement.nextElementSibling)head.parentElement.nextElementSibling.textContent=sum.toFixed(1)+'h';const chart=$('.h-36',card);if(chart)$$(':scope>div',chart).forEach((col,i)=>{const spans=$$(':scope>span',col),bar=$(':scope>div',col);if(spans[0])spans[0].textContent=weeks[i].toFixed(1)+'h';if(spans[1])spans[1].textContent=i===3?'近7天':`${4-i}周前`;if(bar)bar.style.height=Math.max(2,weeks[i]/max*90)+'%'});const footer=$(':scope>div:last-child',card);if(footer)footer.innerHTML=`<span>有效学习记录</span><span>${logs.length} 次</span>`}}
$$('a').filter(a=>getText(a)==='今日专注').forEach(a=>attachAction(a,timerModal));
}
function recordList(title, records, describe, open, summary=''){
 const body=(summary?`<p class="dz-muted">${esc(summary)}</p>`:'')+
   (records.length?`<div class="dz-records">${records.map((record,i)=>{
     const [name,meta]=describe(record);
     return `<button type="button" class="dz-row dz-record-row" data-record="${i}"><span class="dz-row-text"><strong>${esc(name)}</strong><span class="dz-muted" style="display:block">${esc(meta)}</span></span>${icon('chevron_right')}</button>`;
   }).join('')}</div>`:empty('没有符合条件的记录'));
 const overlay=modal(title,body,{wide:true});
 overlay.addEventListener('click',e=>{
   const row=e.target.closest('[data-record]');
   if(row)open(records[Number(row.dataset.record)],()=>recordList(title,records,describe,open,summary));
 });
}
function logRecords(title, records){
 const sorted=[...records].sort((a,b)=>b.date.localeCompare(a.date));
 const total=sorted.reduce((sum,log)=>sum+Number(log.minutes),0);
 recordList(title,sorted,log=>[log.title,`${log.date} · ${log.minutes} 分钟`],(log,back)=>{
   const goal=state.goals.find(g=>g.id===log.goal);
   const o=modal(log.title,`<p class="dz-muted">${esc(log.date)} · ${esc(log.minutes)} 分钟</p>
     <p>关联目标：${esc(goal?.title||'未关联')}</p>
     <p style="white-space:pre-wrap">${esc(log.note||'暂无复盘心得')}</p>
     <div class="dz-actions">${btn('返回记录列表','records-back')}${btn('编辑记录','record-edit','primary')}</div>`);
   attachAction($('[data-action=records-back]',o),back);
   attachAction($('[data-action=record-edit]',o),()=>logForm(log));
 },`${sorted.length} 条学习记录 · 共 ${total} 分钟`);
}
function taskRecords(title,records){
 recordList(title,records,t=>[t.title,[t.subject,t.date||'未安排日期',t.start,t.done?'已完成':'待完成'].filter(Boolean).join(' · ')],
   (t,back)=>taskDetail(t.id,back),`${records.length} 项任务`);
}
function chapterRecords(goal, completedOnly=false){
 if(!goal)return goalList();
 const items=completedOnly?goal.chapters.filter(c=>c.done):goal.chapters;
 recordList(completedOnly?'已完成核心章节':'章节进度明细',items,
   c=>[c.title,`${c.category} · ${c.done?'已完成':'待完成'}`],c=>chapterForm(goal,c),
   `${goal.title} · ${goal.chapters.filter(c=>c.done).length} / ${goal.chapters.length} 节`);
}
function bindRecordDetails(){
 function bind(card,label,action){
   if(!card)return;
   card.classList.add('dz-metric-interactive');
   card.setAttribute('aria-label',label);
   attachAction(card,action);
 }
 const allLogs=()=>logRecords('学习时长明细',state.logs);
 const completed=()=>taskRecords('已完成任务',state.tasks.filter(t=>t.done));
 if(page==='04-dashboard'){
   const cards=$$('#dz-dashboard-metrics>div');
   const labels=[state.logs.length+' 条记录','共 '+state.tasks.length+' 项',
     state.tasks.filter(t=>!t.done&&t.date===today()).length+' 项在今天','未设日期'];
   cards.forEach((card,i)=>{const badge=card.firstElementChild?.lastElementChild;if(badge)badge.textContent=labels[i]});
   bind(cards[0],'查看学习时长明细',allLogs);
   bind(cards[1],'查看已完成任务',completed);
   bind(cards[2],'查看进行中的任务',()=>taskRecords('进行中的任务',state.tasks.filter(t=>!t.done&&t.date)));
   bind(cards[3],'查看待安排任务',()=>taskRecords('待安排任务',state.tasks.filter(t=>!t.done&&!t.date)));
   $$('main .h-44>div').forEach((col,i)=>{
     const day=dayPlus(today(),i-6);
     bind(col,`查看 ${day} 专注记录`,()=>logRecords(day+' 专注记录',state.logs.filter(l=>l.date===day)));
   });
   const heading=findExact('专注趋势','h3');
   const footer=heading?.closest('[class*="rounded-"]')?.lastElementChild;
   bind(footer,'查看最近七天专注记录',()=>logRecords('最近七天专注记录',
     state.logs.filter(l=>l.date>=dayPlus(today(),-6)&&l.date<=today())));
 }
 if(page==='11-mobile-dashboard'){
   const cards=$$('section[aria-label="核心指标"] article');
   bind(cards[0],'查看近七天专注明细',()=>logRecords('近七天专注明细',
     state.logs.filter(l=>l.date>=dayPlus(today(),-6)&&l.date<=today())));
   bind(cards[1],'查看已完成任务',completed);
   bind(cards[2],'查看进行中的任务',()=>taskRecords('进行中的任务',state.tasks.filter(t=>!t.done&&t.date)));
   bind(cards[3],'查看待安排任务',()=>taskRecords('待安排任务',state.tasks.filter(t=>!t.done&&!t.date)));
 }
 if(page==='02-goal-detail'){
   const cards=$$('main>section:nth-child(2)>div');
   const goal=selectedGoal();
   const logs=()=>state.logs.filter(l=>l.goal===goal?.id);
   bind(cards[0],'查看章节进度明细',()=>chapterRecords(goal));
   bind(cards[1],'查看已完成章节',()=>chapterRecords(goal,true));
   bind(cards[2],'查看有效专注明细',()=>logRecords('有效专注明细',logs()));
   bind(cards[3],'查看目标与截止日期',()=>{
     if(!goal)return goalList();
     const remaining=goal.deadline?Math.ceil((new Date(goal.deadline)-new Date(today()))/864e5):null;
     const status=remaining===null?'未设截止日期':remaining<0?`已超过截止日期 ${-remaining} 天`:remaining===0?'今天到期':`距截止日期还有 ${remaining} 天`;
     const o=modal(goal.title,`<p>${esc(status)}</p><p class="dz-muted">${esc(goal.deadline||'')} · ${esc(goal.subject)}</p>${btn('编辑学习目标','deadline-edit','primary')}`);
     attachAction($('[data-action=deadline-edit]',o),()=>goalForm(goal));
   });
   const workCard=findExact('近 4 周有效工时','h3')?.closest('.card-clean');
   bind(workCard?.lastElementChild,'查看最近四周有效工时',()=>logRecords('最近四周有效工时',
     logs().filter(l=>l.date>=dayPlus(today(),-27)&&l.date<=today())));
   $$('.h-36>div',workCard||document).forEach((col,i)=>{
     const from=dayPlus(today(),-27+i*7),to=dayPlus(today(),-21+i*7);
     bind(col,`查看 ${from} 至 ${to} 学习记录`,()=>logRecords(`${from} 至 ${to}`,
       logs().filter(l=>l.date>=from&&l.date<=to)));
   });
 }
 if(page==='07-study-group'){
   const group=state.groups[0];
   if(!group)return;
   const filters=[['小组任务',()=>true],['已交付任务',t=>t.done],
     ['待推进任务',t=>!t.done],['待分配任务',t=>!t.owner]];
   $$('#dz-group-metrics .text-metric-lg').slice(0,4).forEach((num,i)=>{
     const [label,filter]=filters[i];
     const card=num.closest('[class*="rounded-"]');
     bind(card,'查看'+label,()=>recordList(label,group.tasks.filter(filter),
       t=>[t.title,`${t.owner||'未分配'} · ${t.done?'已交付':'待推进'}`],(t,back)=>{
         const o=modal(t.title,`<p>负责人：${esc(t.owner||'未分配')}</p><p>状态：${t.done?'已交付':'待推进'}</p>${btn('返回任务列表','group-record-back')}`);
         attachAction($('[data-action=group-record-back]',o),back);
       }));
   });
 }
}

let rendered=false;
function refresh(){
 const previous=rendered?motion.snapshot():null;
 const completed=motion.completionSnapshot();
if(page==='conversation-import')renderImports();if(page==='today-analysis')todayRender();if(page==='10-tasks')taskListRender();if(page==='06-materials')materialRender();if(page==='02-goal-detail')goalRender();if(page==='04-dashboard'||page==='11-mobile-dashboard')dashboardRender();if(page==='09-calendar')calendarRender(true);if(page==='07-study-group')groupRender();if(page==='01-account')accountRender();reconcile();bindRecordDetails();hydrateAvatar();timerRender();
 if(rendered||!shell)motion.metrics(previous);motion.completion(completed);
 if(!rendered&&!shell)enterScreen();
 rendered=true;
}
function enterScreen(){
 motion.metrics(null);
 if(page==='02-goal-detail'&&window.gsap&&!reduced()){
   gsap.from('[data-chapter]',{y:8,opacity:0,duration:.34,delay:.06,stagger:.045,ease:'power2.out',clearProps:'transform,opacity'});
 }
}
function revealScreen(){
 const prepare=()=>requestAnimationFrame(()=>requestAnimationFrame(()=>{
   document.documentElement.classList.add('dz-ready');
   shell?.ready(window);
 }));
 if(document.fonts)document.fonts.ready.then(prepare,prepare);
 else prepare();
}
function offline(){let el=$('.dz-offline');if(!navigator.onLine&&!el){el=document.createElement('div');el.className='dz-offline';el.textContent='当前离线 · 已加载的页面与本地数据仍可使用';el.setAttribute('role','status');document.body.append(el)}else if(navigator.onLine)el?.remove()}
try{document.documentElement.classList.toggle('dz-dark',state.settings.theme==='dark');navInit();refresh();pageBindings();generalBindings();animate();offline();setInterval(()=>{if(page==='today-analysis'&&$('#daily-date')?.dataset.date!==today())refresh();timerRender();const timer=$('#dz-timer-read');if(timer){const t=state.timer,s=Math.floor((t.elapsed+(t.running?Date.now()-t.started:0))/1000);timer.textContent=[Math.floor(s/3600),Math.floor(s/60)%60,s%60].map(x=>String(x).padStart(2,'0')).join(':')}},1000);addEventListener('online',offline);addEventListener('offline',offline);addEventListener('storage',e=>{if(e.key===stateKey){try{state=JSON.parse(e.newValue)||seed();refresh()}catch{toast('跨页面数据读取失败，请刷新',true)}}});window.Donezo={enter:enterScreen,getState:()=>structuredClone(state),refresh,taskForm,goalForm,logForm,materialOpen,canLeave:()=>canLeaveDialog(),hasDialog:()=>!!closeCurrent,dismissDialog:()=>{if(!closeCurrent)return false;closeCurrent();return true}};}catch(e){console.error('Donezo initialization error',e);toast('页面部分交互初始化失败，请刷新重试',true)}
revealScreen();
})();
