(() => {
  const pages = {
    dashboard: ['仪表盘', 'dashboard', '04-dashboard'],
    materials: ['学习资料', 'menu_book', '06-materials'],
    goal: ['学习进度', 'insights', '02-goal-detail'],
    tasks: ['任务', 'task_alt', '10-tasks'],
    calendar: ['日历', 'calendar_today', '09-calendar'],
    group: ['小组', 'groups', '07-study-group'],
    logs: ['学习记录', 'edit_note', '05-study-logs'],
    settings: ['设置', 'settings', '03-settings'],
    account: ['个人中心', 'account_circle', '01-account'],
    detail: ['资料详情', 'menu_book', '08-material-detail']
  };
  const frame = document.querySelector('#screen');
  const workspace = document.querySelector('#workspace');
  const side = document.querySelector('#side-menu');
  const indicator = document.querySelector('#indicator');
  const bottom = document.querySelector('#bottom-menu');
  const scrim = document.querySelector('#scrim');
  const narrow = matchMedia('(max-width:1023px)');
  const reduced = matchMedia('(prefers-reduced-motion:reduce)');
  const trail = [];
  let current, requestedPath;

  function menuButton(key, label, icon, handler) {
    const button = document.createElement('button');
    button.dataset.route = key;
    button.innerHTML = `<span class="symbol" aria-hidden="true">${icon}</span><span>${label}</span>`;
    button.addEventListener('click', handler);
    return button;
  }

  function drawer(open) {
    document.body.classList.toggle('drawer', open);
    scrim.hidden = !open;
    bottom.querySelector('[data-route=more]').setAttribute('aria-expanded', String(open));
    updateIndicator(false);
  }

  for (const [key, [label, icon]] of Object.entries(pages)) {
    if (key === 'detail') continue;
    if (key === 'dashboard' || key === 'logs') {
      const heading = document.createElement('div');
      heading.className = 'menu-label';
      heading.textContent = key === 'dashboard' ? 'MENU' : 'GENERAL';
      side.append(heading);
    }
    side.append(menuButton(key, label, icon, () => navigate(key)));
  }
  for (const key of ['dashboard', 'materials', 'tasks', 'calendar']) {
    bottom.append(menuButton(key, pages[key][0], pages[key][1], () => navigate(key)));
  }
  bottom.append(menuButton('more', '更多', 'more_horiz', () => drawer(true)));
  scrim.addEventListener('click', () => drawer(false));

  function updateIndicator(animate = true) {
    if (!current) return;
    const key = current.key === 'detail' ? 'materials' : current.key;
    const active = side.querySelector(`[data-route="${key}"]`);
    for (const button of document.querySelectorAll('[data-route]')) {
      const selected = button.dataset.route === key ||
        (button.dataset.route === 'more' && !bottom.querySelector(`[data-route="${key}"]`));
      if (selected) button.setAttribute('aria-current', 'page');
      else button.removeAttribute('aria-current');
    }
    const y = active.offsetTop;
    if (animate && !reduced.matches && window.gsap) {
      gsap.to(indicator, {y, duration: .36, ease: 'power3.out', overwrite: true});
    } else {
      window.gsap?.killTweensOf(indicator);
      indicator.style.transform = `translateY(${y}px)`;
      window.gsap?.set(indicator, {y});
    }
  }

  function routePath(key, query) {
    const folder = key === 'dashboard' && workspace.clientWidth < 768 ? '11-mobile-dashboard' : pages[key][2];
    return `/${folder}/${query}`;
  }

  function load() {
    const path = routePath(current.key, current.query);
    if (path === requestedPath) return;
    requestedPath = path;
    workspace.setAttribute('aria-busy', 'true');
    frame.title = pages[current.key][0];
    frame.contentWindow.location.replace(path);
  }

  function navigate(key, query = '') {
    if (!Object.hasOwn(pages, key)) return false;
    const wasOpen = !scrim.hidden;
    if (current?.key !== key || current.query !== query) {
      if (current && frame.contentWindow.Donezo?.canLeave() === false) return false;
      if (current) trail.push(current);
      current = {key, query};
      updateIndicator(!!trail.length);
      load();
    }
    if (wasOpen) {
      document.body.classList.remove('drawer');
      scrim.hidden = true;
      bottom.querySelector('[data-route=more]').setAttribute('aria-expanded', 'false');
    }
    return true;
  }

  function back() {
    if (!scrim.hidden) { drawer(false); return true; }
    if (frame.contentWindow.Donezo?.dismissDialog()) return true;
    if (!trail.length) return false;
    current = trail.pop();
    updateIndicator();
    load();
    return true;
  }

  function syncTheme() {
    try {
      const state = JSON.parse(localStorage.getItem('donezo-state-v1'));
      document.documentElement.classList.toggle('dark', state?.settings?.theme === 'dark');
    } catch {}
  }

  window.DonezoShell = {
    navigate,
    back,
    save: window.DonezoNative ? message => window.DonezoNative.postMessage(message) : null
  };
  frame.addEventListener('load', () => {
    if (!requestedPath || frame.contentWindow.location.pathname !== requestedPath.split('?')[0]) return;
    workspace.setAttribute('aria-busy', 'false');
    syncTheme();
  });
  window.addEventListener('storage', syncTheme);
  window.addEventListener('keydown', event => {
    if (event.key === 'Escape' && !scrim.hidden) drawer(false);
  });
  new ResizeObserver(() => {
    if (current?.key === 'dashboard' && !frame.contentWindow.Donezo?.hasDialog()) load();
  }).observe(workspace);
  narrow.addEventListener('change', () => drawer(false));
  syncTheme();
  drawer(false);
  navigate('dashboard', location.search);
})();
