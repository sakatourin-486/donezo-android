(() => {
  const pages = {
    today: ['今日分析', 'today', 'today'],
    dashboard: ['仪表盘', 'dashboard', '04-dashboard'],
    materials: ['学习资料', 'menu_book', '06-materials'],
    goal: ['学习进度', 'insights', '02-goal-detail'],
    tasks: ['任务', 'task_alt', '10-tasks'],
    calendar: ['日历', 'calendar_today', '09-calendar'],
    group: ['小组', 'groups', '07-study-group'],
    logs: ['学习记录', 'edit_note', '05-study-logs'],
    settings: ['设置', 'settings', '03-settings'],
    account: ['个人中心', 'account_circle', '01-account'],
    imports: ['导入', 'input', 'import'],
    detail: ['资料详情', 'menu_book', '08-material-detail']
  };
  let frame = document.querySelector('#screen');
  const workspace = document.querySelector('#workspace');
  const reduced = matchMedia('(prefers-reduced-motion:reduce)');
  const trail = [];
  let current, requestedPath, pending, exiting;
  const navigation = createGlassNavigation({pages, navigate, workspace});

  function routePath(key, query) {
    const folder = key === 'dashboard' && workspace.clientWidth < 768 ? '11-mobile-dashboard' : pages[key][2];
    return `/${folder}/${query}`;
  }

  function discardPending() {
    if (!pending) return;
    clearTimeout(pending.timeout);
    pending.element.remove();
    pending = null;
  }

  function load() {
    const path = routePath(current.key, current.query);
    if (path === requestedPath) return;
    discardPending();
    if (exiting) {
      window.gsap?.killTweensOf(frame);
      frame.style.opacity = '1';
      exiting.remove();
      exiting = null;
    }
    requestedPath = path;
    if (frame.dataset.path === path) {
      frame.inert = false;
      workspace.setAttribute('aria-busy', 'false');
      return;
    }
    workspace.setAttribute('aria-busy', 'true');
    frame.inert = true;
    const next = document.createElement('iframe');
    next.className = 'dz-screen dz-screen-pending';
    next.title = pages[current.key][0];
    next.inert = true;
    next.setAttribute('aria-hidden', 'true');
    workspace.append(next);
    pending = {element:next, path, route:{...current}};
    pending.timeout = setTimeout(() => {
      if (pending?.element !== next) return;
      discardPending();
      requestedPath = frame.dataset.path;
      frame.inert = false;
      workspace.setAttribute('aria-busy', 'false');
      showLoadError();
    }, 15000);
    next.contentWindow.location.replace(path);
  }

  function showLoadError() {
    document.querySelector('#load-error')?.remove();
    const retry = document.createElement('button');
    retry.id = 'load-error';
    retry.textContent = '页面加载失败，点击重试';
    retry.addEventListener('click', () => {
      retry.remove();
      requestedPath = null;
      load();
    });
    workspace.append(retry);
  }

  function ready(source) {
    const next = pending?.element;
    if (!next || next.contentWindow !== source) return;
    clearTimeout(pending.timeout);
    const path = pending.path;
    pending = null;
    const previous = frame;
    previous.inert = true;
    previous.removeAttribute('id');
    previous.setAttribute('aria-hidden', 'true');
    exiting = previous;
    frame = next;
    frame.id = 'screen';
    frame.dataset.path = path;
    frame.classList.remove('dz-screen-pending');
    frame.inert = false;
    frame.removeAttribute('aria-hidden');
    workspace.setAttribute('aria-busy', 'false');
    document.querySelector('#load-error')?.remove();
    syncTheme();
    source.Donezo?.enter();
    const finish = () => {
      previous.remove();
      if (exiting === previous) exiting = null;
    };
    if (reduced.matches || !window.gsap) {
      frame.style.opacity = '1';
      finish();
    } else {
      gsap.fromTo(frame, {opacity:0}, {
        opacity:1, duration:.16, ease:'power1.out', overwrite:true, onComplete:finish
      });
    }
  }

  function navigate(key, query = '') {
    if (!Object.hasOwn(pages, key)) return false;
    if (current?.key !== key || current.query !== query) {
      if (current && frame.contentWindow.Donezo?.canLeave() === false) return false;
      if (current) trail.push(current);
      current = {key, query};
      navigation.setActive(key);
      load();
    }
    navigation.close();
    return true;
  }

  function back() {
    if (navigation.isOpen()) { navigation.close(); return true; }
    if (frame.contentWindow.Donezo?.dismissDialog()) return true;
    if (!trail.length) return false;
    current = trail.pop();
    navigation.setActive(current.key);
    load();
    return true;
  }

  function syncTheme() {
    try {
      const state = JSON.parse(localStorage.getItem(window.DonezoCloud.stateKey()));
      document.documentElement.classList.toggle('dark', state?.settings?.theme === 'dark');
    } catch {}
  }

  window.DonezoShell = {
    navigate,
    cloud:window.DonezoCloud,
    back,
    ready,
    save: window.DonezoNative ? message => window.DonezoNative.postMessage(message) : null
  };
  window.addEventListener('storage', syncTheme);
  new ResizeObserver(() => {
    if (current?.key === 'dashboard' && !frame.contentWindow.Donezo?.hasDialog()) load();
  }).observe(workspace);
  syncTheme();
  const startPage = new URLSearchParams(location.search).get('page');
  navigate(startPage === 'account' ? 'account' : 'today');
})();
