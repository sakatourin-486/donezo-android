/* One glass surface changes from the fixed circular launcher into the page menu. */
window.createGlassNavigation = function ({pages, navigate, workspace}) {
  const root = document.querySelector('#glass-nav');
  const surface = document.querySelector('#nav-surface');
  const panel = document.querySelector('#nav-panel');
  const toggle = document.querySelector('#nav-toggle');
  const plus = document.querySelector('#nav-plus');
  const closeButton = document.querySelector('#nav-close');
  const scrim = document.querySelector('#nav-scrim');
  const list = document.querySelector('#nav-list');
  const indicator = document.querySelector('#nav-indicator');
  const glint = surface.querySelector('.glass-glint');
  const reduced = matchMedia('(prefers-reduced-motion:reduce)');
  const buttons = [];
  let expanded = false;
  let activeKey = 'today';
  let animation;
  let restoreFocusOnClose = false;

  for (const [key, [label, icon]] of Object.entries(pages)) {
    if (key === 'detail') continue;
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'glass-route';
    button.dataset.route = key;
    button.innerHTML = `<span class="symbol" aria-hidden="true">${icon}</span>
      <span class="route-label">${label}</span>
      <svg class="route-check" viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="m4 10 4 4 8-8" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
    button.addEventListener('click', () => navigate(key));
    buttons.push(button);
    list.append(button);
  }

  function setActive(key, animated = expanded) {
    activeKey = key === 'detail' ? 'materials' : key;
    let selected;
    for (const button of buttons) {
      if (button.dataset.route === activeKey) {
        button.setAttribute('aria-current', 'page');
        selected = button;
      } else button.removeAttribute('aria-current');
    }
    if (!selected) return;
    toggle.setAttribute('aria-label', '打开页面导航，当前为' + pages[activeKey][0]);
    const y = selected.offsetTop;
    if (window.gsap && animated && !reduced.matches) {
      gsap.to(indicator, {y, duration:.28, ease:'power3.out', overwrite:true});
    } else if (window.gsap) gsap.set(indicator, {y});
    else indicator.style.transform = `translateY(${y}px)`;
  }

  function hidden() {
    if (expanded) return;
    panel.inert = true;
    panel.setAttribute('aria-hidden', 'true');
    scrim.hidden = true;
    workspace.inert = false;
    root.classList.remove('is-animating');
    if(restoreFocusOnClose){toggle.focus({preventScroll:true});restoreFocusOnClose=false}
  }

  function buildAnimation() {
    animation?.kill();
    const width = root.clientWidth;
    const height = root.clientHeight;
    const size = toggle.offsetWidth;
    root.style.setProperty('--closed-x', size / width);
    root.style.setProperty('--closed-y', size / height);
    if (!window.gsap){root.classList.add('nav-ready');return}
    gsap.set(surface, {scaleX:size/width, scaleY:size/height, borderRadius:'50%'});
    gsap.set(panel, {autoAlpha:0, scale:.88, transformOrigin:"100% 100%"});
    gsap.set(toggle, {autoAlpha:1});
    gsap.set(plus, {rotation:0, scale:1});
    gsap.set(glint, {opacity:0, xPercent:-35});
    animation = gsap.timeline({
      paused:true,
      defaults:{ease:'power2.out'},
      onComplete:() => {
        root.classList.remove('is-animating');
        if (expanded && document.activeElement === toggle) {
          (buttons.find(button=>button.dataset.route===activeKey) || buttons[0]).focus({preventScroll:true});
        }
      },
      onReverseComplete:hidden
    });
    animation
      .to(surface, {scaleX:1, scaleY:1, duration:.40, ease:'back.out(1.08)'}, 0)
      .to(surface, {borderRadius:'30px', duration:.29, ease:'power2.out'}, 0)
      .to(toggle, {autoAlpha:0, duration:.13}, .015)
      .to(plus, {rotation:90, scale:.65, duration:.18}, 0)
      .to(panel, {autoAlpha:1, scale:1, duration:.21}, .11)
      .to(glint, {opacity:.38, xPercent:8, duration:.17}, .07)
      .to(glint, {opacity:0, xPercent:35, duration:.16}, .24);
    animation.progress(expanded ? 1 : 0).pause();
    setActive(activeKey, false);
    root.classList.add('nav-ready');
  }

  function setOpen(open, restoreFocus = true) {
    if (expanded === open) return;
    expanded = open;
    root.classList.toggle('is-open', open);
    restoreFocusOnClose = !open&&restoreFocus;
    toggle.setAttribute('aria-expanded', String(open));
    if (open) {
      scrim.hidden = false;
      panel.inert = false;
      panel.setAttribute('aria-hidden', 'false');
      workspace.inert = true;
      root.classList.add('is-animating');
      setActive(activeKey, false);
      buttons.find(button=>button.dataset.route===activeKey)?.scrollIntoView({block:'nearest',behavior:'instant'});
    } else {
      panel.inert = true;
      panel.setAttribute('aria-hidden', 'true');
      root.classList.add('is-animating');
    }
    if (!animation || reduced.matches) {
      if (animation) animation.progress(open ? 1 : 0).pause();
      else {
        surface.style.transform = open ? 'scale(1)' : '';
        surface.style.borderRadius = open ? '30px' : '';
        panel.style.visibility = open ? 'visible' : 'hidden';
        panel.style.opacity = open ? '1' : '0';
        toggle.style.visibility = open ? 'hidden' : 'visible';
      }
      if (!open) hidden();
      else root.classList.remove('is-animating');
      if (open) (buttons.find(button=>button.dataset.route===activeKey)||buttons[0]).focus({preventScroll:true});
      return;
    }
    if (open) animation.timeScale(1).play();
    else animation.timeScale(1.35).reverse();
  }

  toggle.addEventListener('click', () => setOpen(!expanded));
  closeButton.addEventListener('click', () => setOpen(false));
  scrim.addEventListener('click', () => setOpen(false));
  document.addEventListener('keydown', event => {
    if (!expanded) return;
    if (event.key === 'Escape') {
      event.preventDefault();
      event.stopPropagation();
      setOpen(false);
      return;
    }
    const focusable = [closeButton, ...buttons];
    const current = focusable.indexOf(document.activeElement);
    if (event.key === 'Tab') {
      if (event.shiftKey && current <= 0) {
        event.preventDefault();
        focusable.at(-1).focus();
      } else if (!event.shiftKey && current === focusable.length-1) {
        event.preventDefault();
        closeButton.focus();
      }
    }
    if (['ArrowUp','ArrowDown','Home','End'].includes(event.key)) {
      event.preventDefault();
      const index = buttons.indexOf(document.activeElement);
      const next = event.key === 'Home' ? 0 : event.key === 'End' ? buttons.length-1 :
        (index + (event.key === 'ArrowDown' ? 1 : -1) + buttons.length) % buttons.length;
      buttons[next].focus();
    }
  });
  new ResizeObserver(buildAnimation).observe(root);
  reduced.addEventListener('change', buildAnimation);
  buildAnimation();
  setActive(activeKey, false);
  return {
    setActive,
    close:() => setOpen(false),
    isOpen:() => expanded
  };
};
