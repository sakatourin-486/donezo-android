package com.sakatourin.donezo;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.MimeTypeMap;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import org.json.JSONObject;

/** Local, offline web application. External pages are never loaded in this WebView. */
public final class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private static final int PICK_FILE = 4101;
    private static final int SAVE_FILE = 4102;
    private WebView web;
    private ValueCallback<Uri[]> chooser;
    private byte[] pendingExport;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        web.setBackgroundColor(0xFFF4F7F5);
        setContentView(web);
        if (Build.VERSION.SDK_INT >= 30) {
            web.setOnApplyWindowInsetsListener((v, insets) -> {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
                return insets;
            });
        }
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true); // Only user-selected content:// files from system picker.
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportMultipleWindows(false);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setTextZoom(100);

        // A HTTPS origin preserves IndexedDB/localStorage and root-relative resource paths.
        WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
            .addPathHandler("/", new WebViewAssetLoader.AssetsPathHandler(this))
            .build();
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("https".equals(uri.getScheme()) && HOST.equals(uri.getHost())) {
                    String path = uri.getPath();
                    if (path == null || path.isEmpty()) path = "/";
                    if (path.endsWith("/")) path += "index.html";
                    WebResourceResponse response = loader.shouldInterceptRequest(uri.buildUpon().path(path).build());
                    if (response != null) return response;
                }
                return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", Collections.emptyMap(),
                    new ByteArrayInputStream("Not found".getBytes(StandardCharsets.UTF_8)));
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("https".equals(uri.getScheme()) && HOST.equals(uri.getHost())) return false;
                // A selected document may create a blob: preview in the local page.
                if ("blob".equals(uri.getScheme())) return false;
                if (request.isForMainFrame() && request.hasGesture() &&
                    ("https".equals(uri.getScheme()) || "http".equals(uri.getScheme()) || "mailto".equals(uri.getScheme()))) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
                    catch (Exception ex) { message("没有可打开此链接的应用"); }
                }
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (chooser != null) chooser.onReceiveValue(null);
                chooser = callback;
                String[] types = params.getAcceptTypes();
                boolean multiple = params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE;
                boolean imagesOnly = types.length == 1 && types[0] != null && types[0].startsWith("image/");
                Intent intent;
                if (Build.VERSION.SDK_INT >= 33 && imagesOnly && !multiple) {
                    intent = new Intent(MediaStore.ACTION_PICK_IMAGES).setType("image/*");
                } else {
                    intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType(imagesOnly ? "image/*" : "*/*");
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, multiple);
                    if (!imagesOnly && types.length > 0 && !types[0].isEmpty()) {
                        intent.putExtra(Intent.EXTRA_MIME_TYPES, types);
                    }
                }
                try { startActivityForResult(intent, PICK_FILE); }
                catch (Exception ex) {
                    chooser.onReceiveValue(null); chooser = null;
                    message("系统文件选择器不可用");
                }
                return true;
            }
        });
        // Origin-restricted WebMessage bridge, accepting messages from the main local frame only.
        if (WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            WebViewCompat.addWebMessageListener(web, "DonezoNative", Collections.singleton("https://" + HOST),
                (view, message, sourceOrigin, isMainFrame, reply) -> {
                    if (!isMainFrame || !HOST.equals(sourceOrigin.getHost())) return;
                    try {
                        JSONObject data = new JSONObject(message.getData());
                        if (!"save".equals(data.optString("action"))) return;
                        if (pendingExport != null) { message("请先完成当前文件保存"); return; }
                        String encoded = data.getString("data");
                        if (encoded.length() > 30 * 1024 * 1024) { message("导出文件过大"); return; }
                        pendingExport = Base64.decode(encoded, Base64.DEFAULT);
                        String name = data.optString("name", "donezo-export.json").replaceAll("[\\\\/:*?\"<>|]", "_");
                        String mime = data.optString("mime", "application/octet-stream");
                        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                            .setType(mime).putExtra(Intent.EXTRA_TITLE, name);
                        startActivityForResult(intent, SAVE_FILE);
                    } catch (Exception ex) { pendingExport = null; message("无法导出文件，请重试"); }
                });
        }
        web.loadUrl("https://" + HOST + "/index.html");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILE && chooser != null) {
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null) {
                ArrayList<Uri> selected = new ArrayList<>();
                ClipData clip = data.getClipData();
                if (clip != null) {
                    for (int i = 0; i < clip.getItemCount(); i++) selected.add(clip.getItemAt(i).getUri());
                } else if (data.getData() != null) selected.add(data.getData());
                result = selected.toArray(new Uri[0]);
            }
            chooser.onReceiveValue(result);
            chooser = null;
        }
        if (requestCode == SAVE_FILE) {
            byte[] bytes = pendingExport;
            pendingExport = null;
            if (resultCode != RESULT_OK || data == null || data.getData() == null || bytes == null) return;
            Uri destination = data.getData();
            new Thread(() -> {
                try (OutputStream output = getContentResolver().openOutputStream(destination)) {
                    if (output == null) throw new IOException("No output stream");
                    output.write(bytes);
                    runOnUiThread(() -> message("文件已保存"));
                } catch (Exception ex) { runOnUiThread(() -> message("保存失败，请重试")); }
            }, "donezo-export").start();
        }
    }

    @Override public void onBackPressed() {
        // Close the in-page dialog before leaving the current page.
        web.evaluateJavascript("!!document.querySelector('.dz-overlay')", result -> {
            if ("true".equals(result)) {
                web.evaluateJavascript("document.querySelector('.dz-overlay .dz-dialog-head button')?.click()", null);
            } else if (web.canGoBack()) web.goBack(); else super.onBackPressed();
        });
    }
    @Override protected void onDestroy() {
        if (chooser != null) { chooser.onReceiveValue(null); chooser = null; }
        web.destroy();
        super.onDestroy();
    }
    private void message(String text) { Toast.makeText(this, text, Toast.LENGTH_SHORT).show(); }
}
