# 学记 Donezo · Android 源码

保留现有 11 个 Stitch 页面、组件样式、图片、字体和 GSAP 动画。APK 内置前端资源，用 Android WebView 加载，打开应用不依赖已发布网站，也不需要登录 ChatGPT。

## 在 GitHub 自动生成 APK

1. 解压本源码包，将其中的全部文件和目录上传至 GitHub 仓库**根目录**。不要只把 ZIP 上传到仓库。
2. 必须包含 `.github/workflows/android.yml`。部分安卓文件管理器会隐藏以点开头的目录，请打开“显示隐藏文件”。
3. 提交到 `main` 或 `master` 后，在仓库的 **Actions → Build Android APK** 中查看构建；也可点击 **Run workflow** 手动运行。
4. 任务出现绿色勾后，在该次运行页面底部 **Artifacts → Donezo-Study-APK** 下载压缩包，解压后得到 `Donezo-Study-1.0.4.apk`，发送到安卓设备安装。

若新仓库提示启用 Actions，先启用。这里不要求你填写密钥或付费服务配置。GitHub Actions 的实际可用额度以你的账号为准。

## 头像从相册上传

打开 **更多 → 账号与个人中心**，点击现有头像或“编辑资料”，选择图片、预览后保存。头像在各页面的个人头像位置同步显示。

Android 13 及以上优先使用系统照片选择器；旧系统使用系统文件选择器，不申请访问全部照片或全部文件的权限。支持浏览器可解码的 JPG、PNG、WebP，单张最多 8MB；保存前缩放至最长边 512px，头像轮廓仍沿用原设计的圆形。照片只保存在应用本地。

## 工程结构

- `app/src/main/assets/`：完整前端成品，可直接修改 HTML/CSS/JS；页面效果沿用原网站。
- `app/src/main/assets/shared/app.js`：学习数据、交互、GSAP、头像选择预览及保存。
- `app/src/main/java/com/sakatourin/donezo/MainActivity.java`：WebView、本地 HTTPS 资源、照片/文件选择、导出文件保存及返回键处理。
- `.github/workflows/android.yml`：自动构建并上传 APK。
- `signing/development.keystore`：仅用于此演示应用的固定开发签名，默认密码 `android`；后续构建使用同一签名可以覆盖安装。此开发签名不是生产上架密钥，请勿用于其他应用或作为正式商店发布签名。

## 构建环境

GitHub 工作流配置为 JDK 17、Gradle 8.9、Android Gradle Plugin 8.7.3、compile/target SDK 35，最低 Android 8.0（API 26）。项目不需要 Node.js，也不需要从 CDN 下载前端脚本。

本地安装好上述环境后，可执行 `gradle :app:assembleDebug`。当前包交付的是源码，不包含已经编译或在安卓真机运行验证的 APK；首次 GitHub 构建会验证 Android 编译和资源打包。

## 数据与功能边界

任务、进度、学习资料和头像保存在应用本地；网页版本与 APK 的数据不会自动互通。卸载应用或清除应用数据会清空本地记录。可在应用中导出 JSON 备份；JSON 不含附件文件本体。

系统文件选择器用于导入学习资料；系统“另存为”界面用于导出文件。文件导出桥接仅接受应用本地 HTTPS 来源的主页面消息，外部链接交给设备浏览器打开，不在应用 WebView 中加载远程网页。

此版本继承前端版本的功能范围：小组为本机演示，真实登录、跨设备同步与多人协作尚未接入后端。原型中账号安全和云同步部分仅为界面示例，不表示实际已启用。

## 修改后更新

修改前端资源并提交即可重新打包；发布新版时在 `app/build.gradle` 增加 `versionCode` 并修改 `versionName`。保持 `applicationId` 和开发签名文件不变，避免因签名改变导致无法覆盖安装。
